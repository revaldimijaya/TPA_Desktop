﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApplication_JY201
{
    class Connect
    {
        private static UnderTheSeaEntities db;

        public Connect()
        {

        }

        public static UnderTheSeaEntities getInstance()
        {
            if (db == null) db = new UnderTheSeaEntities();

            return db;
        }
    }
}
