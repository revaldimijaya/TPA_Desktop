﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WpfApplication_JY201.Repository;

namespace WpfApplication_JY201.Controller
{
    class AdvertismentController
    {
        public static List<Advertisment> ViewAdvertisment()
        {
            return AdvertismentRepository.ViewAdvertisment();
        }

        public static Advertisment GetOne(int id)
        {
            return AdvertismentRepository.GetOne(id);
        }

        public static void AddAdvertisment(Advertisment advertisment)
        {
            AdvertismentRepository.AddAdvertisment(advertisment);
        }

        public static void UpdateAdvertisment(int id, string name, string description)
        {
            AdvertismentRepository.UpdateAdvertisment(id, name, description);
        }

        public static void DeleteAdvertisment(int id)
        {
            AdvertismentRepository.DeleteAdvertisment(id);
        }
    }
}
