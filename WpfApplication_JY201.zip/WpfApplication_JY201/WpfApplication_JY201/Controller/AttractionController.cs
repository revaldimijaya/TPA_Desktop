﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WpfApplication_JY201.Repository;

namespace WpfApplication_JY201.Controller
{
    class AttractionController
    {
        public static Attraction GetOne(int id)
        {
            return AttractionRepository.GetOne(id);
        }

        public static List<Attraction> ViewAttraction()
        {
            return AttractionRepository.ViewAttraction();
        }

        public static void AddAttraction(Attraction attraction)
        {
            AttractionRepository.AddAttraction(attraction);
        }

        public static void UpdateAttraction(int id, string status, string description)
        {
            AttractionRepository.UpdateAttraction(id, status, description);
        }

        public static void RemoveAttraction(int id)
        {
            AttractionRepository.RemoveAttraction(id);
        }
    }
}
