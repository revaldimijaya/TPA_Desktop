﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WpfApplication_JY201.Repository;

namespace WpfApplication_JY201.Controller
{
    class AttractionMaintenanceController
    {
        public static List<AttractionMaintenance> ViewAttractionMaintenance()
        {
            return AttractionMaintenanceRepository.ViewAttractionMaintenance();
        }

        public static AttractionMaintenance GetOne(int id)
        {
            return AttractionMaintenanceRepository.GetOne(id);
        }

        public static void AddAttractionMaintenance(AttractionMaintenance att)
        {
            AttractionMaintenanceRepository.AddAttractionMaintenance(att);
        }

        public static void UpdateAttractionMaintenance(int id, DateTime sDate, DateTime fDate)
        {
            AttractionMaintenanceRepository.UpdateAttractionMaintenance(id, sDate, fDate);
        }

        public static void RemoveAttractionMaintenance(int id)
        {
            AttractionMaintenanceRepository.RemoveAttractionMaintenance(id);
        }
    }
}
