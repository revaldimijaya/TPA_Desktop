﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WpfApplication_JY201.Repository;

namespace WpfApplication_JY201.Controller
{
    class AttractionPlanController
    {
        public static List<AttractionPlan> ViewAttractionPlan()
        {
            return AttractionPlanRepository.ViewAttractionPlan();
        }

        public static AttractionPlan GetOne(int id)
        {
            return AttractionPlanRepository.GetOne(id);
        }

        public static void AddAttractionPlan(AttractionPlan att)
        {
            AttractionPlanRepository.AddAttractionPlan(att);
        }

        public static void UpdateAttractionPlan(int id, string name, string description)
        {
            AttractionPlanRepository.UpdateAttractionPlan(id, name, description);
        }

        public static void RemoveAttractionPlan(int id)
        {
            AttractionPlanRepository.RemoveAttractionPlan(id);
        }

        public static void SetStatus(int id, string status)
        {
            AttractionPlanRepository.SetStatus(id, status);
        }
    }

}
