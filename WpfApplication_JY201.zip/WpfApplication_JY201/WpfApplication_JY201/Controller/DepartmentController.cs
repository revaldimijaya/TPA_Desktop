﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WpfApplication_JY201.Repository;

namespace WpfApplication_JY201.Controller
{
    class DepartmentController
    {
        public static Department GetOne(int id)
        {
            return DepartmentRepository.GetOne(id);
        }

        public static List<Department> ViewDepartment()
        {
            return DepartmentRepository.ViewDepartment();
        }
    }
}
