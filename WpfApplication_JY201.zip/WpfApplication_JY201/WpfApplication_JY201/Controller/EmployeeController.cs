﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WpfApplication_JY201.Repository;

namespace WpfApplication_JY201.Controller
{
    class EmployeController
    {
        public static Employee GetEmployee(int employeeId)
        {
            return EmployeeRepository.GetEmployee(employeeId);
        }

        public static Employee GetEmployee(string employeeName)
        {
            return EmployeeRepository.GetEmployee(employeeName);
        }

        public static void SetEmployeeSalary(int employeeId, int employeeSalary)
        {
            EmployeeRepository.SetEmployeeSalary(employeeId, employeeSalary);
        }

        public static void SetEmployeeStatus(int employeeId, string employeeStatus)
        {
            EmployeeRepository.SetEmployeeStatus(employeeId, employeeStatus);
        }

        public static void RemoveEmployee(int employeeId)
        {
            EmployeeRepository.RemoveEmployee(employeeId);
        }

        public static List<Employee> ViewEmployee()
        {
            return EmployeeRepository.ViewEmployee();
        }

        public static void AddEmployee(Employee employee)
        {
            EmployeeRepository.AddEmployee(employee);
        }
    }
}
