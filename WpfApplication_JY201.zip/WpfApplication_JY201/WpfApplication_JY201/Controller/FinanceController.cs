﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WpfApplication_JY201.Repository;

namespace WpfApplication_JY201.Controller
{
    class FinanceController
    {
        public static List<Finance> ViewFinance()
        {
            return FinancialRepository.ViewFinance();
        }

        public static Finance GetOne(int id)
        {
            return FinancialRepository.GetOne(id);
        }

        public static void AddFinance(Finance finance)
        {
            FinancialRepository.AddFinance(finance);
        }

        public static void UpdateFinance(int id, int amount, string description)
        {
            FinancialRepository.UpdateFinance(id, amount, description);
        }

        public static void DeleteFinance(int id)
        {
            FinancialRepository.DeleteFinance(id);
        }
    }
}
