﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WpfApplication_JY201.Repository;

namespace WpfApplication_JY201.Controller
{
    class HotelTransactionController
    {
        public static List<HotelTransaction> ViewHotel()
        {
            return HotelTransactionRepository.ViewHotel();
        }

        public static HotelTransaction GetOne(int id)
        {
            return HotelTransactionRepository.GetOne(id);
        }

        public static HotelTransaction GetVisitorId(int visitorId)
        {
            return HotelTransactionRepository.GetVisitorId(visitorId);
        }

        public static void AddHotel(HotelTransaction hotel)
        {
            HotelTransactionRepository.AddHotel(hotel);
        }

        public static void UpdateHotel(int id, DateTime booking)
        {
            HotelTransactionRepository.UpdateHotel(id, booking);
        }

        public static void SetStatus(int id, string status)
        {
            HotelTransactionRepository.SetStatus(id, status);
        }
    }
}
