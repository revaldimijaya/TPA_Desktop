﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WpfApplication_JY201.Repository;

namespace WpfApplication_JY201.Controller
{
    class IncomeController
    {
        public static List<Income> ViewIncome()
        {
            if (Global.GetEmployeeId() != 15) return null;

            return IncomeRepository.ViewIncome();
        }

        public static void AddIncome(Income income)
        {
            IncomeRepository.AddIncome(income);
        }
    }
}
