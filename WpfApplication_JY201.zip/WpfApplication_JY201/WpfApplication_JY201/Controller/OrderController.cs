﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WpfApplication_JY201.Repository;

namespace WpfApplication_JY201.Controller
{
    class OrderController
    {
        public static List<Order> ViewOrder()
        {
            return OrderRepository.ViewOrder();
        }

        public static List<Order> ViewOrderChef()
        {
            return OrderRepository.ViewOrderChef();
        }

        public static Order GetOne(int id)
        {
            return OrderRepository.GetOne(id);
        }

        public static void AddOrder(Order order)
        {
            OrderRepository.AddOrder(order);
        }

        public static void UpdateOrder(int id, int table, string description, int amount)
        {
            OrderRepository.UpdateOrder( id,  table,  description,  amount);
        }

        public static void SetStatus(int id, string status)
        {
            OrderRepository.SetStatus(id, status);
        }

        public static void DeleteOrder(int id)
        {
            OrderRepository.DeleteOrder(id);
        }
    }
}
