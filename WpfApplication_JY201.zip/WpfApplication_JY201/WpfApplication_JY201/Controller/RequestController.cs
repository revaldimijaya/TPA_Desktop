﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WpfApplication_JY201.Repository;

namespace WpfApplication_JY201.Controller
{
    class RequestController
    {
        public static Request GetOne(int id)
        {
            return RequestRepository.GetOne(id);
        }

        public static List<Request> ViewRequest()
        {
            return RequestRepository.ViewRequest();
        }

        public static List<Request> ViewRequestSpecific(int id)
        {
            return RequestRepository.ViewRequest(id);
        }

        public static void AddRequest(Request request)
        {
            RequestRepository.AddRequest(request);
        }

        public static void DeleteRequest(int id)
        {
            if (GetOne(id) == null)
            {
                return;
            }

            RequestRepository.DeleteRequest(id);
        }

        public static void SetStatus(int id, string status)
        {
            if (GetOne(id) == null)
            {
                return;
            }

            RequestRepository.SetStatus(id, status);
        }
    }
}
