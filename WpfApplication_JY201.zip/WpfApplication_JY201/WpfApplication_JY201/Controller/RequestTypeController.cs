﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WpfApplication_JY201.Repository;

namespace WpfApplication_JY201.Controller
{
    class RequestTypeController
    {
        public static RequestType GetOne(int id)
        {
            return RequestTypeRepository.GetOne(id);
        }

        public static RequestType GetOne(string name)
        {
            return RequestTypeRepository.GetOne(name);
        }

        public static List<RequestType> ViewRequestType()
        {
            return RequestTypeRepository.ViewRequestType();
        }

        public static void AddRequestType(RequestType type)
        {
            RequestTypeRepository.AddRequestType(type);
        }

        public static void DeleteRequestType(int id)
        {
            RequestTypeRepository.DeleteRequestType(id);
        }
    }
}
