﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WpfApplication_JY201.Repository;

namespace WpfApplication_JY201.Controller
{
    class RideController
    {
        public static List<Ride> ViewRide()
        {
            return RideRepository.ViewRide();
        }

        public static void AddRide(Ride ride)
        {
            RideRepository.AddRide(ride);
        }

        public static void RemoveRide(int id)
        {
            RideRepository.RemoveRide(id);
        }

        public static void UpdateRide(int id, string status, string rideDescription)
        {
            RideRepository.UpdateRide(id, status, rideDescription);
        }
    }
}
