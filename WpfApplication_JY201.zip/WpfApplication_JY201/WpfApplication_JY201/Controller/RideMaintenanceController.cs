﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WpfApplication_JY201.Repository;

namespace WpfApplication_JY201.Controller
{
    class RideMaintenanceController
    {
        public static List<RideMaintenance> ViewRideMaintenance()
        {
            return RideMaintenanceRepository.ViewRideMaintenance();
        }

        public static RideMaintenance GetOne(int id)
        {
            return RideMaintenanceRepository.GetOne(id);
        }

        public static void AddRideMaintenance(RideMaintenance ride)
        {
            RideMaintenanceRepository.AddRideMaintenance(ride);
        }

        public static void RemoveRideMaintenance(int id)
        {
            RideMaintenanceRepository.RemoveRideMaintenance(id);
        }

        public static void UpdateRideMaintenance(int id, DateTime fDate, DateTime eDate)
        {
            RideMaintenanceRepository.UpdateRideMaintenance(id, fDate, eDate);
        }
    }
}
