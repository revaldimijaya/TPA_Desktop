﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WpfApplication_JY201.Repository;

namespace WpfApplication_JY201.Controller
{
    class RidePlanController
    { 
        public static List<RidePlanning> ViewRidePlan()
        {
            return RidePlanRepository.ViewRidePlan();
        }

        public static RidePlanning GetOne(int id)
        {
            return RidePlanRepository.GetOne(id);
        }

        public static void AddRidePlan(RidePlanning ride)
        {
            RidePlanRepository.AddRidePlan(ride);
        }

        public static void UpdateRidePlan(int id, string name, string description)
        {
            RidePlanRepository.UpdateRidePlan(id, name, description);
        }

        public static void RemoveRidePlan(int id)
        {
            RidePlanRepository.RemoveRidePlan(id);
        }

        public static void SetStatus(int id, string status)
        {
            RidePlanRepository.SetStatus(id, status);
        }
    }
}
