﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WpfApplication_JY201.Repository;

namespace WpfApplication_JY201.Controller
{
    class RoomController
    {
        public static Room GetOne(string room)
        {
            return RoomRepository.GetOne(room);
        }

        public static List<Room> ViewAllRoom()
        {
            return RoomRepository.ViewAllRoom();
        }

        public static List<Room> ViewBookedRoom()
        {
            return RoomRepository.ViewBookedRoom();
        }

        public static List<Room> ViewAvailableRoom()
        {
            return RoomRepository.ViewAvailableRoom();
        }

        public static void SetStatus(int id, string status)
        {
            RoomRepository.SetStatus(id, status);
        }
    }
}
