﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WpfApplication_JY201.Repository;

namespace WpfApplication_JY201.Controller
{
    class TicketController
    {
        public static void AddTicket(Ticket ticket)
        {
            TicketRepository.AddTicket(ticket);
        }

        public static List<Ticket> ViewTicket()
        {
            return TicketRepository.ViewTicket();
        }

        public static Ticket CheckTicket(int TicketId)
        {
            Ticket ticket = new Ticket();
            ticket = TicketRepository.ViewTicket(TicketId);

            if (ticket != null)
            {
                return ticket;
            }
            return null;
        }

        public static void GenerateQR()
        {

        }
    }
}
