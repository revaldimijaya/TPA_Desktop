﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WpfApplication_JY201.Repository;

namespace WpfApplication_JY201.Controller
{
    class VisitorController
    {
        public static List<Visitor> ViewVisitor()
        {
            return VisitorRepository.ViewVisitor();
        }

        public static Visitor GetOne(int id)
        {
            return VisitorRepository.GetOne(id);
        }

        public static Visitor GetOne(string identity)
        {
            return VisitorRepository.GetOne(identity);
        }

        public static void AddVisitor(Visitor visitor)
        {
            VisitorRepository.AddVisitor(visitor);
        }

        public static void UpdateVisitor(int id, string name, string identity)
        {
            VisitorRepository.UpdateVisitor(id, name, identity);
        }

        public static void DeleteVisitor(int id)
        {
            VisitorRepository.DeleteVisitor(id);
        }
    }
}
