﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApplication_JY201.Factory
{
    class AdvertismentFactory
    {
        public static Advertisment CreateAdvertisment(string name, string description)
        {
            Advertisment ad = new Advertisment();
            ad.AdvertismentName = name;
            ad.AdvertismentDescription = description;
            return ad;
        }
    }
}
