﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApplication_JY201.Factory
{
    class AttractionFactory
    {
        public static Attraction CreateAttraction (int id, string name, string description, string status)
        {
            Attraction att = new Attraction();
            att.EmployeeId = id;
            att.AttractionName = name;
            att.AttractionDescription = description;
            att.AttractionStatus = status;
            return att;
        }
    }
}
