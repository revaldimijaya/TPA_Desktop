﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApplication_JY201.Factory
{
    class AttractionMaintenanceFactory
    {
        public static AttractionMaintenance CreateAttractionMaintenance(int id, DateTime sDate, DateTime fDate)
        {
            AttractionMaintenance att = new AttractionMaintenance();
            att.AttractionId = id;
            att.StartDateMaintenance = sDate;
            att.FinishDateMaintenance = fDate;
            return att;
        }

    }
}
