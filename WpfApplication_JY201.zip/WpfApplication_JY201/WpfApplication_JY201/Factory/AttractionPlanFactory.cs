﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApplication_JY201.Factory
{
    class AttractionPlanFactory
    {
        public static AttractionPlan CreateAttractionPlan(int id, string name, string status, string description)
        {
            AttractionPlan att = new AttractionPlan();
            att.EmployeeId = id;
            att.AttractionPlanName = name;
            att.AttractionPlanStatus = status;
            att.AttractionPlanDescription = description;
            return att;
        }
    }
}
