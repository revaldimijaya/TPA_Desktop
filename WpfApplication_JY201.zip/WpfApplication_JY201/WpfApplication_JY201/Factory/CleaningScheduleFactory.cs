﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApplication_JY201.Factory
{
    class CleaningScheduleFactory
    {
        public static CleaningSchedule CreateCleaning(DateTime schedule, string status, int room)
        {
            CleaningSchedule cs = new CleaningSchedule();
            cs.CleaningSchedule1 = schedule;
            cs.CleaningStatus = status;
            cs.RoomId = room;
            return cs;
        }
    }
}
