﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApplication_JY201.Factory
{
    class EmployeeFactory
    {
        public static Employee CreateEmployee(int roleId, int departmentId, string name, int age, string email, string password, int salary, DateTime startWork, string endWork, string status)
        {
            Employee employee = new Employee();
            employee.RoleId = roleId;
            employee.DepartmentId = departmentId;
            employee.EmployeeName = name;
            employee.EmployeeAge = age;
            employee.EmployeeEmail = email;
            employee.EmployeePassword = password;
            employee.EmployeeSalary = salary;
            employee.EmployeeStartWork = startWork;
            employee.EmployeeEndWork = null;
            employee.EmployeeStatus = status;

            return employee;
        }
    }
}
