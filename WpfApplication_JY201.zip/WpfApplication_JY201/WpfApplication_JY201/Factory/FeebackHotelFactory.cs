﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApplication_JY201.Factory
{
    class FeebackHotelFactory
    {
        public static FeedbackHotel CreateFeedback(int hotel, string description)
        {
            FeedbackHotel feed = new FeedbackHotel();
            feed.Description = description;
            
            return feed;
        }
    }
}
