﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApplication_JY201.Factory
{
    class FeedbackRestaurantFactory
    {
        public static FeedbackRestaurant CreateFeedback(int hotel, string description)
        {
            FeedbackRestaurant feed = new FeedbackRestaurant();
            feed.Description = description;
            return feed;
        }
    }
}
