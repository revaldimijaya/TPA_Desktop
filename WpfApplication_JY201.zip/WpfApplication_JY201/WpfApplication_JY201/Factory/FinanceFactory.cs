﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApplication_JY201.Factory
{
    class FinanceFactory
    {
        public static Finance CreateFinance(int amount, string description)
        {
            Finance finance = new Finance();
            finance.FinanceAmount = amount;
            finance.FinanceDescription = description;
            finance.FinanceDate = DateTime.Now;
            return finance;
        }
    }
}
