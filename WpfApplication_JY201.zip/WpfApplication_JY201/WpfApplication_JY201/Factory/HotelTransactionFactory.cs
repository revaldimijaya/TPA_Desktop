﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApplication_JY201.Factory
{
    class HotelTransactionFactory
    {
        public static HotelTransaction CreateHotel(int employee, int visitor, int room, DateTime date, string status, string description)
        {
            HotelTransaction hotel = new HotelTransaction();
            hotel.EmployeeId = employee;
            hotel.VisitorId = visitor;
            hotel.RoomId = room;
            hotel.BookingDate = date;
            hotel.TransactionStatus = status;
            hotel.TransactionDescription = description;
            return hotel;
        }
    }
}
