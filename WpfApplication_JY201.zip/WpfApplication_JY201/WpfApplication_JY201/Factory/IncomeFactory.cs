﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApplication_JY201.Factory
{
    class IncomeFactory
    {
        public static Income CreateIncome(int departmentId, int amount, string description)
        {
            Income income = new Income();
            income.DepartmentId = departmentId;
            income.IncomeAmount = amount;
            income.IncomeDescription = description;
            return income;
        }
    }
}
