﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApplication_JY201.Factory
{
    class OrderFactory
    {
        public static Order CreateOrder(int table, string description, int amount, string status)
        {
            Order order = new Order();
            order.OrderTable = table;
            order.OrderDescription = description;
            order.OrderAmount = amount;
            order.OrderStatus = "Ordered";
            return order;
        }
    }
}
