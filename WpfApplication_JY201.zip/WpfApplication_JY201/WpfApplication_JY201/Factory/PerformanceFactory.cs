﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApplication_JY201.Factory
{
    class PerformanceFactory
    {
        public static Performance CreatePerformance(int employee, DateTime date, string description)
        {
            Performance per = new Performance();
            per.EmployeeId = employee;
            per.Date = date;
            per.Description = description;
            return per;
        }
    }
}
