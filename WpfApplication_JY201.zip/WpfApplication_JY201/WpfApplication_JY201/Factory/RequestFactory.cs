﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApplication_JY201.Factory
{
    class RequestFactory
    {
        public static Request CreateRequest(int type, int department, string description)
        {
            Request request = new Request();
            request.RequestTypeId = type;
            request.FromDepartmentId = 
            request.ToDepartmentId = department;
            request.RequestDescription = description;
            request.RequestStatus = "Pending";
            return request;
        }
    }
}
