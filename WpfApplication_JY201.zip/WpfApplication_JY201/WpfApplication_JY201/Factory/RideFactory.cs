﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApplication_JY201.Factory
{
    class RideFactory
    {
        public static Ride CreateRide(int employee, string name, string description)
        {
            Ride ride = new Ride();
            ride.EmployeeId = employee;
            ride.RideName = name;
            ride.RideDescription = description;
            return ride;
        }
    }
}
