﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApplication_JY201.Factory
{
    class RideMaintenanceFactory
    {
        public static RideMaintenance CreateRideMaintenance(int rideId, DateTime sDate, DateTime fDate)
        {
            RideMaintenance rm = new RideMaintenance();
            rm.RideId = rideId;
            rm.StartDateMaintenance = sDate;
            rm.FinishDateMaintenance = fDate;
            return rm;
        }
    }
}
