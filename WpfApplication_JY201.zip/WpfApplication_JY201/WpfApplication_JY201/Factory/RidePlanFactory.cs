﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApplication_JY201.Factory
{
    class RidePlanFactory
    {
        public static RidePlanning CreateRidePlan(int id, string name, string description, string status)
        {
            RidePlanning ride = new RidePlanning();
            ride.EmployeeId = id;
            ride.RideName = name;
            ride.RideDescription = description;
            ride.RideStatus = status;
            return ride;
        }
    }
}
