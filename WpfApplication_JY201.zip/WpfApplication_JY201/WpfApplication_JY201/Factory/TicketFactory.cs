﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApplication_JY201.Factory
{
    class TicketFactory
    {
        public static Ticket CreateTicket(int EmployeeId, string TicketDate, int TicketPrice, int TicketQuantity)
        {
            Ticket ticket = new Ticket();
            ticket.EmployeeId = EmployeeId;
            ticket.TicketDate = Convert.ToDateTime(TicketDate);
            ticket.TicketPrice = TicketPrice;
            ticket.TicketQuantity = TicketQuantity;
            return ticket;
        }
    }
}
