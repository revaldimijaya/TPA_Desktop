﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApplication_JY201.Factory
{
    class VisitorFactory
    {
        public static Visitor CreateVisitor(string name, string identity)
        {
            Visitor visitor = new Visitor();
            visitor.VisitorName = name;
            visitor.IdentityCard = identity;
            return visitor;
        }
    }
}
