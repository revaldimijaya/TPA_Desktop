﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApplication_JY201
{
    class Global
    {
        public static int _EmployeeId;
        public static int _DepartmentId;

        public static int GetEmployeeId()
        {
            return _EmployeeId;
        }

        public static void SetEmployeeId(int employeeId, int departmentId)
        {
            _EmployeeId = employeeId;
            _DepartmentId = departmentId;
        }

        public static int GetDepartmentId()
        {
            return _DepartmentId;
        }

    }
}
