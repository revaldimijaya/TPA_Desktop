﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApplication_JY201
{
    class Global
    {
        private static int _EmployeeId;
        private static int _DepartmentId;

        public static int GetEmployeeId()
        {
            return _EmployeeId;
        }

        public static void SetEmployeeId(int employeeId)
        {
            _EmployeeId = employeeId;
        }

        public static int GetDepartmentId()
        {
            return _DepartmentId;
        }

        public static void setDepartmentId(int departmentId)
        {
            _DepartmentId = departmentId;
        }



    }
}
