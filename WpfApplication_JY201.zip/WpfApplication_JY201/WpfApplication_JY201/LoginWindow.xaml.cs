﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using WpfApplication_JY201.Controller;
using WpfApplication_JY201.ViewWindow.AttractiveWindow;
using WpfApplication_JY201.ViewWindow.ManagerWindow;

namespace WpfApplication_JY201
{
    /// <summary>
    /// Interaction logic for LoginWindow.xaml
    /// </summary>
    public partial class LoginWindow : Window
    {
        public LoginWindow()
        {
            InitializeComponent();
        }

        private void btnSubmit_Click(object sender, RoutedEventArgs e)
        {
            string password = txtPassword.Password.ToString();
            string name = txtName.Text;

            Employee employee = EmployeController.GetEmployee(name);

            if (employee.EmployeePassword == password)
            {
                Global.SetEmployeeId(employee.EmployeeId);

                if (employee.RoleId == 1)
                {
                    AttractiveWindow aw = new AttractiveWindow();
                    aw.Show();
                    this.Close();
                }
                else if (employee.RoleId == 15)
                {
                    ManagerWindow mw = new ManagerWindow();
                    mw.Show();
                    this.Close();
                }
            }
            else
            {
                MessageBox.Show("invalid username / password");
            }
        }
    }
}
