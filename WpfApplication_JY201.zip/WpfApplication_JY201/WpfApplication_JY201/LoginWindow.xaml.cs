﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using WpfApplication_JY201.Controller;
using WpfApplication_JY201.ViewWindow.AccountingWindow;
using WpfApplication_JY201.ViewWindow.AdvertismentWindow;
using WpfApplication_JY201.ViewWindow.AttractiveWindow;
using WpfApplication_JY201.ViewWindow.ConstructionWindow;
using WpfApplication_JY201.ViewWindow.CreativeWindow;
using WpfApplication_JY201.ViewWindow.HotelWindow;
using WpfApplication_JY201.ViewWindow.HRDWindow;
using WpfApplication_JY201.ViewWindow.MaintenanceWindow;
using WpfApplication_JY201.ViewWindow.ManagerWindow;
using WpfApplication_JY201.ViewWindow.PurchasingWindow;
using WpfApplication_JY201.ViewWindow.RestaurantWindow;

namespace WpfApplication_JY201
{
    /// <summary>
    /// Interaction logic for LoginWindow.xaml
    /// </summary>
    public partial class LoginWindow : Window
    {
        public LoginWindow()
        {
            InitializeComponent();
        }

        private void btnSubmit_Click(object sender, RoutedEventArgs e)
        {
            string password = txtPassword.Password.ToString();
            string name = txtName.Text;

            Employee employee = EmployeController.GetEmployee(name);
            if(employee == null || password == null)
            {
                MessageBox.Show("Wrong username / pass");
                return;
            }
            if (employee.EmployeePassword == password)
            {
                Global.SetEmployeeId(employee.EmployeeId, (int)employee.DepartmentId);

                if (employee.RoleId == 1)
                {
                    AttractiveWindow aw = new AttractiveWindow();
                    aw.Show();
                    this.Close();
                }
                else if (employee.RoleId == 15)
                {
                    ManagerWindow mw = new ManagerWindow();
                    mw.Show();
                    this.Close();
                }
                else if(employee.RoleId == 2)
                {
                    MaintenanceWindow mw = new MaintenanceWindow();
                    mw.Show();
                    this.Close();
                }
                else if(employee.RoleId == 3)
                {
                    CreativeWindow cw = new CreativeWindow();
                    cw.Show();
                    this.Close();
                }
                else if(employee.RoleId == 4)
                {
                    ConstructionWindow cw = new ConstructionWindow();
                    cw.Show();
                    this.Close();
                }
                else if(employee.RoleId == 5)
                {
                    RestaurantWindow rw = new RestaurantWindow();
                    rw.Show();
                    this.Close();
                }
                else if(employee.RoleId == 7)
                {
                    RestaurantWindowChef rwc = new RestaurantWindowChef();
                    rwc.Show();
                    this.Close();
                }
                else if(employee.RoleId == 8)
                {
                    PurchasingWindow pw = new PurchasingWindow();
                    pw.Show();
                    this.Close();
                }
                else if(employee.RoleId == 9)
                {
                    AccountingWindow aw = new AccountingWindow();
                    aw.Show();
                    this.Close();
                }
                else if(employee.RoleId == 10)
                {
                    HouseKeeperWindow hkw = new HouseKeeperWindow();
                    hkw.Show();
                    this.Close();
                }
                else if(employee.RoleId == 12)
                {
                    ReceptionistWindow rw = new ReceptionistWindow();
                    rw.Show();
                    this.Close();
                }
                else if(employee.RoleId == 13)
                {
                    AdvertismentWindow aw = new AdvertismentWindow();
                    aw.Show();
                    this.Close();
                }
                else if(employee.RoleId == 14)
                {
                    HRDWindow hrd = new HRDWindow();
                    hrd.Show();
                    this.Close();
                }
                else if(employee.RoleId == 15)
                {
                    ManagerWindow mw = new ManagerWindow();
                    mw.Show();
                    this.Close();
                }
            }
            else
            {
                MessageBox.Show("invalid username / password");
            }
        }
    }
}
