﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApplication_JY201.Repository
{
    class AdvertismentRepository
    {
        static UnderTheSeaEntities db = Connect.getInstance();

        public static List<Advertisment> ViewAdvertisment()
        {
            return db.Advertisments.Where(a => a.DeletedAt == null).ToList();
        } 

        public static Advertisment GetOne(int id)
        {
            return db.Advertisments.Where(a => a.AdvertismentId == id && a.DeletedAt == null).FirstOrDefault();
        }

        public static void AddAdvertisment(Advertisment advertisment)
        {
            db.Advertisments.Add(advertisment);
            db.SaveChanges();
        }

        public static void UpdateAdvertisment(int id, string name, string description)
        {
            Advertisment ad = GetOne(id);
            ad.AdvertismentName = name;
            ad.AdvertismentDescription = description;
            db.SaveChanges();
        }

        public static void DeleteAdvertisment(int id)
        {
            Advertisment ad = GetOne(id);
            ad.DeletedAt = DateTime.Now;
            db.SaveChanges();
        }
    }
}
