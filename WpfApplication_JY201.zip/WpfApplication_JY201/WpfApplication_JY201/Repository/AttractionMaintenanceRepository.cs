﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApplication_JY201.Repository
{
    class AttractionMaintenanceRepository
    {
        static UnderTheSeaEntities db = Connect.getInstance();

        public static List<AttractionMaintenance> ViewAttractionMaintenance()
        {
            return db.AttractionMaintenances.Where(a => a.DeletedAt == null).ToList();
        }

        public static AttractionMaintenance GetOne(int id)
        {
            return db.AttractionMaintenances.Where(a => a.AttractionId == id && a.DeletedAt == null).FirstOrDefault();
        }

        public static void AddAttractionMaintenance(AttractionMaintenance att)
        {
            db.AttractionMaintenances.Add(att);
            db.SaveChanges();
        }

        public static void UpdateAttractionMaintenance(int id, DateTime sDate, DateTime fDate)
        {
            AttractionMaintenance att = GetOne(id);
            att.StartDateMaintenance =sDate;
            att.FinishDateMaintenance =fDate;
            db.SaveChanges();
        }

        public static void RemoveAttractionMaintenance(int id)
        {
            AttractionMaintenance att = GetOne(id);
            att.DeletedAt = DateTime.Now;
            db.SaveChanges();
        }
    }
}
