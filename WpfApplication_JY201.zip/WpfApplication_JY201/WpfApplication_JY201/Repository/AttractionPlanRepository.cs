﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApplication_JY201.Repository
{
    class AttractionPlanRepository
    {
        static UnderTheSeaEntities db = Connect.getInstance();

        public static List<AttractionPlan> ViewAttractionPlan()
        {
            return db.AttractionPlans.Where(a => a.DeletedAt == null).ToList();
        }

        public static AttractionPlan GetOne(int id)
        {
            return db.AttractionPlans.Where(a => a.AttractionPlanId == id).FirstOrDefault();
        }

        public static void AddAttractionPlan(AttractionPlan att)
        {
            db.AttractionPlans.Add(att);
            db.SaveChanges();
        }

        public static void UpdateAttractionPlan(int id, string name, string description)
        {
            AttractionPlan att = GetOne(id);
            att.AttractionPlanName = name;
            att.AttractionPlanDescription = description;
            db.SaveChanges();
        }

        public static void RemoveAttractionPlan(int id)
        {
            AttractionPlan att = GetOne(id);
            att.DeletedAt = DateTime.Now;
            db.SaveChanges();
        }

        public static void SetStatus(int id, string status)
        {
            AttractionPlan att = GetOne(id);
            att.AttractionPlanStatus = status;
            db.SaveChanges();
        }
    }
}
