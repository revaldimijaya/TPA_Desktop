﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApplication_JY201.Repository
{
    class AttractionRepository
    {
        static UnderTheSeaEntities db = Connect.getInstance();

        public static Attraction GetOne(int id)
        {
            return db.Attractions.Where(a => a.AttractionId == id).FirstOrDefault();
        }

        public static List<Attraction> ViewAttraction()
        {
            return db.Attractions.Where(a => a.DeletedAt == null).ToList();
        }

        public static void AddAttraction(Attraction attraction)
        {
            db.Attractions.Add(attraction);
            db.SaveChanges();
        }

        public static void UpdateAttraction(int id, string status, string description)
        {
            Attraction attraction = GetOne(id);
            attraction.AttractionStatus = status;
            attraction.AttractionDescription = description;
            db.SaveChanges();
        }

        public static void RemoveAttraction(int id)
        {
            Attraction attraction = GetOne(id);
            attraction.DeletedAt = DateTime.Now;
            db.SaveChanges();
        }
    }
}
