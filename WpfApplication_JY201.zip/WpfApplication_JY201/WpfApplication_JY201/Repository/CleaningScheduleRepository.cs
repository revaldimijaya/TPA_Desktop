﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApplication_JY201.Repository
{
    class CleaningScheduleRepository
    {
        static UnderTheSeaEntities db = Connect.getInstance();

        public static List<CleaningSchedule> ViewCleaning()
        {
            return db.CleaningSchedules.Where(a => a.DeletedAt == null).ToList();
        }

        public static CleaningSchedule GetOne(int id)
        {
            return db.CleaningSchedules.Where(a => a.CleaningId == id).FirstOrDefault();
        }

        public static void AddCleaning(CleaningSchedule cs)
        {
            db.CleaningSchedules.Add(cs);
            db.SaveChanges();
        }

        public static void SetStatus(int id, string status, string description)
        {
            CleaningSchedule cs = GetOne(id);
            cs.CleaningStatus = status;
            cs.Description = description;
            db.SaveChanges();
        }

        public static void DeleteCleaning(int id)
        {
            CleaningSchedule cs = GetOne(id);
            cs.DeletedAt = DateTime.Now;
            db.SaveChanges();
        }
    }
}
