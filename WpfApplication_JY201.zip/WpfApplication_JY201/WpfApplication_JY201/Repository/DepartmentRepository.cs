﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApplication_JY201.Repository
{
    class DepartmentRepository
    {
        static UnderTheSeaEntities db = new UnderTheSeaEntities();
        
        public static Department GetOne(int id)
        {
            return db.Departments.Where(a => a.DepartmentId == id).FirstOrDefault();
        }

        public static List<Department> ViewDepartment()
        {
            return db.Departments.ToList();
        }
    }
}
