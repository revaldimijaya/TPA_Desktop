﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApplication_JY201.Repository
{
    class DepartmentRepository
    {
        static UnderTheSeaEntities db = Connect.getInstance();

        public static Department GetOne(int id)
        {
            return db.Departments.Where(a => a.DepartmentId == id).FirstOrDefault();
        }

        public static Department GetOne(string name)
        {
            return db.Departments.Where(a => a.DepartmentName == name).FirstOrDefault();
        }

        public static List<Department> ViewDepartment()
        {
            return db.Departments.ToList();
        }
    }
}
