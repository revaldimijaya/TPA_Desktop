﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApplication_JY201.Repository
{
    class EmployeeRepository
    {
        static UnderTheSeaEntities db = new UnderTheSeaEntities();

        public static Employee GetEmployee(string name)
        {
            return db.Employees.Where(employee => employee.EmployeeName == name).FirstOrDefault();
        }

        public static Employee GetEmployee(int id)
        {
            return db.Employees.Where(employee => employee.EmployeeId == id).FirstOrDefault();
        }

        public static List<Employee> ViewEmployee()
        {
            return db.Employees.ToList();
        }

        public static void AddEmployee(Employee employee)
        {
            db.Employees.Add(employee);
            db.SaveChanges();
        }

        public static void SetEmployeeSalary(int employeeId, int employeeSalary)
        {
            Employee employee = GetEmployee(employeeId);
            employee.EmployeeSalary = employeeSalary;
            db.SaveChanges();
        }

        public static void SetEmployeeStatus(int employeeId, string employeeStatus)
        {
            Employee employee = GetEmployee(employeeId);
            employee.EmployeeStatus = employeeStatus;
            db.SaveChanges();
        }

        public static void RemoveEmployee(int employeeId)
        {
            Employee employee = GetEmployee(employeeId);
            db.Employees.Remove(employee);
            db.SaveChanges();
        }
    }
}
