﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApplication_JY201.Repository
{
    class FeedbackHotelRepository
    {
        static UnderTheSeaEntities db = Connect.getInstance();

        public static List<FeedbackHotel> ViewFeedback()
        {
            return db.FeedbackHotels.ToList();
        }

        public static void AddFeedback(FeedbackHotel feed)
        {
            db.FeedbackHotels.Add(feed);
            db.SaveChanges();
        }
    }
}
