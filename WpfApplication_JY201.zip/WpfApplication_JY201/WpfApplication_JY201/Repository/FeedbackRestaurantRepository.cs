﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApplication_JY201.Repository
{
    class FeedbackRestaurantRepository
    {
        static UnderTheSeaEntities db = Connect.getInstance();

        public static List<FeedbackRestaurant> ViewFeedback()
        {
            return db.FeedbackRestaurants.ToList();
        }

        public static void AddFeedback(FeedbackRestaurant feed)
        {
            db.FeedbackRestaurants.Add(feed);
            db.SaveChanges();
        }
    }
}
