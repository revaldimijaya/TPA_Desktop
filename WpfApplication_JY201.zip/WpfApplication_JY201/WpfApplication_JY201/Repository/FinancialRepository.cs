﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApplication_JY201.Repository
{
    class FinancialRepository
    {
        static UnderTheSeaEntities db = Connect.getInstance();

        public static List<Finance> ViewFinance()
        {
            return db.Finances.Where(a => a.DeletedAt == null).ToList();
        }

        public static Finance GetOne(int id)
        {
            return db.Finances.Where(a => a.FinanceId == id).FirstOrDefault();
        }

        public static void AddFinance(Finance finance)
        {
            db.Finances.Add(finance);
            db.SaveChanges();
        }

        public static void UpdateFinance(int id, int amount, string description)
        {
            Finance finance = GetOne(id);
            finance.FinanceDate = DateTime.Now;
            finance.FinanceAmount = amount;
            finance.FinanceDescription = description;
            db.SaveChanges();
        }

        public static void DeleteFinance(int id)
        {
            Finance finance = GetOne(id);
            finance.DeletedAt = DateTime.Now;
            db.SaveChanges();
        }
    }
}
