﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApplication_JY201.Repository
{
    class HotelTransactionRepository
    {
        static UnderTheSeaEntities db = Connect.getInstance();

        public static List<HotelTransaction> ViewHotel()
        {
            return db.HotelTransactions.Where(a => a.DeletedAt == null).ToList();
        }

        public static HotelTransaction GetOne(int id)
        {
            return db.HotelTransactions.Where(a => a.HotelTransactionId == id).FirstOrDefault();
        }

        public static HotelTransaction GetVisitorId(int visitorId)
        {
            return db.HotelTransactions.Where(a => a.VisitorId == visitorId).FirstOrDefault();
        }

        public static void AddHotel(HotelTransaction hotel)
        {
            db.HotelTransactions.Add(hotel);
            db.SaveChanges();
        }

        public static void UpdateHotel(int id, DateTime booking)
        {
            HotelTransaction hotel = GetOne(id);
            hotel.BookingDate = booking;
            db.SaveChanges();
        }

        public static void SetStatus(int id, string status)
        {
            HotelTransaction hotel = GetOne(id);
            hotel.TransactionStatus = status;
            db.SaveChanges();
        }
    }

}
