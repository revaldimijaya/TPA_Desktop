﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApplication_JY201.Repository
{
    class IncomeRepository
    {
        static UnderTheSeaEntities db = new UnderTheSeaEntities();

        public static List<Income> ViewIncome()
        {
            return db.Incomes.ToList();
        }

        public static void AddIncome(Income income)
        {
            db.Incomes.Add(income);
            db.SaveChanges();
        }
    }
}
