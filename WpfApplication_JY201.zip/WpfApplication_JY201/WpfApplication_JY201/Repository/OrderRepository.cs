﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApplication_JY201.Repository
{
    class OrderRepository
    {
        static UnderTheSeaEntities db = Connect.getInstance();

        public static List<Order> ViewOrder()
        {
            return db.Orders.Where(a => a.DeletedAt == null).ToList();
        }

        public static List<Order> ViewOrderChef()
        {
            return db.Orders.Where(a => a.DeletedAt == null && a.OrderStatus == "Ordered").ToList();
        }

        public static Order GetOne(int id)
        {
            return db.Orders.Where(a => a.OrderId == id).FirstOrDefault();
        }

        public static void AddOrder(Order order)
        {
            db.Orders.Add(order);
            db.SaveChanges();
        }

        public static void UpdateOrder(int id, int table, string description, int amount)
        {
            Order order = GetOne(id);
            order.OrderTable = table;
            order.OrderDescription = description;
            order.OrderAmount = amount;
            db.SaveChanges();
        }

        public static void SetStatus(int id, string status)
        {
            Order order = GetOne(id);
            order.OrderStatus = status;
            db.SaveChanges();
        }

        public static void DeleteOrder(int id)
        {
            Order order = GetOne(id);
            order.DeletedAt = DateTime.Now;
            db.SaveChanges();
        }
    }
}
