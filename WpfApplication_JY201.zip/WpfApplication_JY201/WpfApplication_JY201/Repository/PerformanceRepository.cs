﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApplication_JY201.Repository
{
    class PerformanceRepository
    {
        static UnderTheSeaEntities db = Connect.getInstance();

        public static List<Performance> ViewPerformance()
        {
            return db.Performances.Where(a => a.DeletedAt == null).ToList();
        }

        public static Performance GetOne(int id)
        {
            return db.Performances.Where(a => a.PerformanceId == id && a.DeletedAt == null).FirstOrDefault();
        }

        public static void AddPerformance(Performance per)
        {
            db.Performances.Add(per);
            db.SaveChanges();
        }

        public static void UpdatePerformance(int id, DateTime date, string description)
        {
            Performance per = GetOne(id);
            per.Date = date;
            per.Description = description;
            db.SaveChanges();
        }

        public static void DeletePerformance(int id)
        {
            Performance per = GetOne(id);
            per.DeletedAt = DateTime.Now;
            db.SaveChanges();
        }
    }
}
