﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApplication_JY201.Repository
{
    class RequestRepository
    {
        static UnderTheSeaEntities db = new UnderTheSeaEntities();

        public static Request GetOne(int id)
        {
            return db.Requests.Where(a => a.RequestId == id).FirstOrDefault();
        }

        public static List<Request> ViewRequest()
        {
            return db.Requests.ToList();
        }

        public static List<Request> ViewRequest(int id)
        {
            return db.Requests.Where(a => a.ToDepartmentId == id).ToList();
        }

        public static void AddRequest(Request request)
        {
            db.Requests.Add(request);
            db.SaveChanges();
        }

        public static void DeleteRequest(int id)
        {
            Request request = GetOne(id);
            db.Requests.Remove(request);
            db.SaveChanges();
        }

        public static void SetStatus(int id, string status)
        {
            Request request = GetOne(id);
            request.RequestStatus = status;
            db.SaveChanges();
        }
    }
}
