﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApplication_JY201.Repository
{
    class RequestRepository
    {
        static UnderTheSeaEntities db = Connect.getInstance();

        public static Request GetOne(int id)
        {
            return db.Requests.Where(a => a.RequestId == id && a.DeletedAt == null).FirstOrDefault();
        }

        public static List<Request> ViewRequest()
        {
            return db.Requests.Where(a => a.DeletedAt == null).ToList();
        }

        public static List<Request> MakeRequest(int id)
        {
            return db.Requests.Where(a => a.EmployeeId == id && a.DeletedAt == null).ToList();
        }

        public static List<Request> IncomingRequest(int id)
        {
            return db.Requests.Where(a => a.ToDepartmentId == id && a.DeletedAt == null).ToList();
        }

        public static void AddRequest(Request request)
        {
            db.Requests.Add(request);
            db.SaveChanges();
        }

        public static void DeleteRequest(int id)
        {
            Request request = GetOne(id);
            request.DeletedAt = DateTime.Now;
            db.SaveChanges();
        }

        public static void UpdateRequest(int id, int typeId ,int toDepartment ,string description)
        {
            Request request = GetOne(id);
            request.RequestTypeId = typeId;
            request.ToDepartmentId = toDepartment;
            request.RequestDescription = description;
            request.CreatedAt = DateTime.Now;
            db.SaveChanges();
        }

        public static void SetStatus(int id, string status)
        {
            Request request = GetOne(id);
            request.RequestStatus = status;
            db.SaveChanges();
        }
    }
}
