﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApplication_JY201.Repository
{
    class RequestTypeRepository
    {
        static UnderTheSeaEntities db = Connect.getInstance();

        public static RequestType GetOne(int id)
        {
            return db.RequestTypes.Where(a => a.RequestTypeId == id).FirstOrDefault();
        }

        public static RequestType GetOne(string name)
        {
            return db.RequestTypes.Where(a => a.RequestTypeName == name).FirstOrDefault();
        }

        public static List<RequestType> ViewRequestType()
        {
            return db.RequestTypes.ToList();
        }

        public static void AddRequestType(RequestType type)
        {
            db.RequestTypes.Add(type);
            db.SaveChanges();
        }

        public static void DeleteRequestType(int id)
        {
            RequestType type = GetOne(id);
            db.RequestTypes.Remove(type);
            db.SaveChanges();
        }
    }
}
