﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApplication_JY201.Repository
{
    class RestaurantTransactionRepository
    {
        static UnderTheSeaEntities db = Connect.getInstance();

        public static List<RestaurantTransaction> ViewRestaurantTransaction()
        {
            return db.RestaurantTransactions.ToList();
        }

        public static RestaurantTransaction GetOne(int id)
        {
            return db.RestaurantTransactions.Where(a => a.RestaurantTransactionId == id).FirstOrDefault();
        }

        public static void AddRestaurantTransaction(RestaurantTransaction rt)
        {
            db.RestaurantTransactions.Add(rt);
            db.SaveChanges();
        }

        public static void DeleteRestaurantTransaction(int id)
        {
            RestaurantTransaction rt = GetOne(id);
            db.RestaurantTransactions.Remove(rt);
            db.SaveChanges();
        }
    }
}
