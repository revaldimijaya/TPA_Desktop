﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApplication_JY201.Repository
{
    class RideMaintenanceRepository
    {
        static UnderTheSeaEntities db = Connect.getInstance();

        public static List<RideMaintenance> ViewRideMaintenance()
        {
            return db.RideMaintenances.Where(a => a.DeletedAt == null).ToList();
        }

        public static RideMaintenance GetOne(int id)
        {
            return db.RideMaintenances.Where(a => a.RideMaintenanceId == id).FirstOrDefault();
        }

        public static void AddRideMaintenance(RideMaintenance ride)
        {
            db.RideMaintenances.Add(ride);
            db.SaveChanges();
        }

        public static void RemoveRideMaintenance(int id)
        {
            RideMaintenance ride = GetOne(id);
            ride.DeletedAt = DateTime.Now;
            db.SaveChanges();
        }

        public static void UpdateRideMaintenance(int id, DateTime sDate, DateTime fDate)
        {
            RideMaintenance ride = GetOne(id);
            ride.StartDateMaintenance = Convert.ToDateTime(sDate);
            ride.FinishDateMaintenance = Convert.ToDateTime(fDate);
            db.SaveChanges();
        }
    }
}
