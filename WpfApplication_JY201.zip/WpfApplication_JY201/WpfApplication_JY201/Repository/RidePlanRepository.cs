﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApplication_JY201.Repository
{
    class RidePlanRepository
    {
        static UnderTheSeaEntities db = Connect.getInstance();

        public static List<RidePlanning> ViewRidePlan()
        {
            return db.RidePlannings.Where(a => a.DeletedAt == null).ToList();
        }

        public static RidePlanning GetOne(int id)
        {
            return db.RidePlannings.Where(a => a.RidePlanningId == id).FirstOrDefault();
        }

        public static void AddRidePlan(RidePlanning ride)
        {
            db.RidePlannings.Add(ride);
            db.SaveChanges();
        }

        public static void UpdateRidePlan(int id, string name, string description)
        {
            RidePlanning ride = GetOne(id);
            ride.RideName = name;
            ride.RideDescription = description;
            db.SaveChanges();
        }

        public static void RemoveRidePlan(int id)
        {
            RidePlanning ride = GetOne(id);
            ride.DeletedAt = DateTime.Now;
            db.SaveChanges();
        }

        public static void SetStatus(int id, string status)
        {
            RidePlanning ride = GetOne(id);
            ride.RideStatus = status;
            db.SaveChanges();
        }
    }
}
