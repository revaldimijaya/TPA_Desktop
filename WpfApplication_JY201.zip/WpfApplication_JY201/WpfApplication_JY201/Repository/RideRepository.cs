﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApplication_JY201.Repository
{
    class RideRepository
    {
        static UnderTheSeaEntities db = Connect.getInstance();

        public static List<Ride> ViewRide()
        {
            return db.Rides.Where(a => a.DeletedAt == null).ToList();
        }

        public static Ride GetOne(int id)
        {
            return db.Rides.Where(a => a.RideId == id).FirstOrDefault();
        }

        public static void AddRide(Ride ride)
        {
            db.Rides.Add(ride);
            db.SaveChanges();
        }

        public static void RemoveRide(int id)
        {
            Ride ride = GetOne(id);
            ride.DeletedAt = DateTime.Now;
            db.SaveChanges();
        }

        public static void UpdateRide(int id, string status, string rideDescription)
        {
            Ride ride = GetOne(id);
            ride.RideStatus = status;
            ride.RideDescription = rideDescription;
            db.SaveChanges();
        }
    }
}
