﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApplication_JY201.Repository
{
    class RoleRepository
    {
        static UnderTheSeaEntities db = Connect.getInstance();

        public static List<Role> ViewRole()
        {
            return db.Roles.ToList();
        }

        public static Role GetOne(string name)
        {
            return db.Roles.Where(a => a.RoleName == name).FirstOrDefault();
        }
    }
}
