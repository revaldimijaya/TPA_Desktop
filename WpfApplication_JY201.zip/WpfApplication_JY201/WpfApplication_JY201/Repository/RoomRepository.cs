﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApplication_JY201.Repository
{
    class RoomRepository
    {
        static UnderTheSeaEntities db = Connect.getInstance();

        public static Room GetOne(int id)
        {
            return db.Rooms.Where(a => a.RoomId == id).FirstOrDefault();
        }

        public static Room GetOne(string room)
        {
            return db.Rooms.Where(a => a.RoomNumber == room).FirstOrDefault();
        }

        public static List<Room> ViewAllRoom()
        {
            return db.Rooms.ToList();
        }

        public static List<Room> ViewBookedRoom()
        {
            return db.Rooms.Where(a => a.RoomStatus == "Booked").ToList();
        }

        public static List<Room> ViewAvailableRoom()
        {
            return db.Rooms.Where(a => a.RoomStatus != "Booked").ToList();
        }

        public static void UpdateRoom (int id, string status, string description)
        {
            Room room = GetOne(id);
            room.RoomStatus = status;
            room.RoomDecription = description;
            db.SaveChanges();
        }

        public static void SetStatus(int id, string status)
        {
            Room room = GetOne(id);
            room.RoomStatus = status;
            db.SaveChanges();
        }
    }
}
