﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApplication_JY201.Repository
{
    class TicketRepository
    {
        static UnderTheSeaEntities db = Connect.getInstance();

        public static List<Ticket> ViewTicket()
        {
            return db.Tickets.ToList();
        }

        public static Ticket ViewTicket(int TicketId)
        {
            return db.Tickets.Where(ticket => ticket.TicketId == TicketId).FirstOrDefault();
        }

        public static void AddTicket(Ticket ticket)
        {
            db.Tickets.Add(ticket);
            db.SaveChanges();
        }

        public static void generateQR()
        {

        }
    }
}
