﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApplication_JY201.Repository
{
    class VisitorRepository
    {
        static UnderTheSeaEntities db = Connect.getInstance();

        public static List<Visitor> ViewVisitor()
        {
            return db.Visitors.Where(a => a.DeletedAt == null).ToList();
        }

        public static Visitor GetOne(int id)
        {
            return db.Visitors.Where(a => a.VisitorId == id).FirstOrDefault();
        }

        public static Visitor GetOne(string identity)
        {
            return db.Visitors.Where(a => a.IdentityCard == identity).FirstOrDefault();
        }

        public static void AddVisitor(Visitor visitor)
        {
            db.Visitors.Add(visitor);
            db.SaveChanges();
        }

        public static void UpdateVisitor(int id, string name, string identity)
        {
            Visitor visitor = GetOne(id);
            visitor.VisitorName = name;
            visitor.IdentityCard = identity;
            db.SaveChanges();
        }

        public static void DeleteVisitor(int id)
        {
            Visitor visitor = GetOne(id);
            visitor.DeletedAt = DateTime.Now;
            db.SaveChanges();
        }
    }
}
