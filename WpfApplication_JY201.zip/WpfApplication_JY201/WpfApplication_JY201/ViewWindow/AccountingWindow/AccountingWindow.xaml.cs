﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApplication_JY201.ViewWindow.AccountingWindow
{
    /// <summary>
    /// Interaction logic for AccountingWindow.xaml
    /// </summary>
    public partial class AccountingWindow : Window
    {
        public AccountingWindow()
        {
            InitializeComponent();
        }

        private void btnIncoming_Click(object sender, RoutedEventArgs e)
        {
            Main.Content = new RequestPage.IncomingPage();
        }

        private void btnLogOut_Click(object sender, RoutedEventArgs e)
        {
            LoginWindow objLw = new LoginWindow();
            objLw.Show();
            this.Close();
        }

        private void btnFinancial_Click(object sender, RoutedEventArgs e)
        {
            Main.Content = new FinancialPage();
        }

        private void btnRequest_Click(object sender, RoutedEventArgs e)
        {
            Main.Content = new RequestPage.RequestPage();
        }
    }
}
