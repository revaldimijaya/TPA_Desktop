﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WpfApplication_JY201.Controller;
using WpfApplication_JY201.Factory;

namespace WpfApplication_JY201.ViewWindow.AccountingWindow
{
    /// <summary>
    /// Interaction logic for FinancialPage.xaml
    /// </summary>
    public partial class FinancialPage : Page
    {
        public FinancialPage()
        {
            InitializeComponent();
            List<Finance> finance = FinanceController.ViewFinance();
            var filtered = finance.Select(i => new
            {
                i.FinanceId,
                i.FinanceAmount,
                i.FinanceDate,
                i.FinanceDescription       
            });

            dgView.ItemsSource = filtered;
        }

        private void btnInsert_Click(object sender, RoutedEventArgs e)
        {
            int amount;
            int.TryParse(txtAmount.Text, out amount);
            string description = txtDescription.Text;

            if(amount <= 0 || description == null)
            {
                MessageBox.Show("Invalid Input!");
                return;
            }

            FinanceController.AddFinance(FinanceFactory.CreateFinance(amount, description));
        }

        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {
            int id, amount;
            int.TryParse(txtAmount.Text, out amount);
            int.TryParse(txtId.Text, out id);
            string description = txtDescription.Text;
            Finance finance = FinanceController.GetOne(id);
            if (finance == null || amount <= 0 || description == null)
            {
                MessageBox.Show("Invalid Input!");
                return;
            }

            FinanceController.UpdateFinance(id, amount, description);
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            int id;
            int.TryParse(txtId.Text, out id);
            Finance finance = FinanceController.GetOne(id);
            if (finance == null )
            {
                MessageBox.Show("Invalid Input!");
                return;
            }

            FinanceController.DeleteFinance(id);
        }
    }
}
