﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WpfApplication_JY201.Controller;
using WpfApplication_JY201.Factory;

namespace WpfApplication_JY201.ViewWindow.AdvertismentWindow
{
    /// <summary>
    /// Interaction logic for AdvertismentPage.xaml
    /// </summary>
    public partial class AdvertismentPage : Page
    {
        public AdvertismentPage()
        {
            InitializeComponent();
            List<Advertisment> ad = AdvertismentController.ViewAdvertisment();
            var filtered = ad.Select(i => new
            {
                i.AdvertismentId,
                i.AdvertismentName,
                i.AdvertismentDescription
            });

            dgView.ItemsSource = filtered;
        }

        private void btnInsert_Click(object sender, RoutedEventArgs e)
        {
            string name = txtName.Text;
            string description = txtDescription.Text;
            if(name == null || description == null)
            {
                MessageBox.Show("Invalid Input!");
                return;
            }

            AdvertismentController.AddAdvertisment(AdvertismentFactory.CreateAdvertisment(name, description));

        }

        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {
            int id;
            int.TryParse(txtId.Text, out id);
            string name = txtName.Text;
            string description = txtDescription.Text;
            Advertisment ad = AdvertismentController.GetOne(id);
            if (ad == null || name == null || description == null)
            {
                MessageBox.Show("Invalid Input!");
                return;
            }

            AdvertismentController.UpdateAdvertisment(id, name, description);
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            int id;
            int.TryParse(txtId.Text, out id);
            Advertisment ad = AdvertismentController.GetOne(id);
            if (ad == null)
            {
                MessageBox.Show("Invalid Input!");
                return;
            }

            AdvertismentController.DeleteAdvertisment(id);
        }
    }
}
