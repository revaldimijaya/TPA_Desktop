﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WpfApplication_JY201.Controller;

namespace WpfApplication_JY201.ViewWindow.AttractiveWindow
{
    /// <summary>
    /// Interaction logic for CheckTicketPage.xaml
    /// </summary>
    public partial class CheckTicketPage : Page
    {
        public CheckTicketPage()
        {
            InitializeComponent();
        }

        private void btnCheck_Click(object sender, RoutedEventArgs e)
        {
            int id;
            int.TryParse(txtTicket.Text, out id);

            if(id == 0)
            {
                MessageBox.Show("Input must be an integer");
                return;
            }

            Ticket ticket = TicketController.CheckTicket(id);

            DateTime dateEnd = ((DateTime)ticket.TicketDate).AddDays(1);
            DateTime dateNow = DateTime.Now;
            end.Content = dateEnd.ToString();
            now.Content = DateTime.Now.ToString();
            
            if(ticket == null)
            {
                lblError.Content = "Invalid id";

            }
            else
            {
                lblError.Content = "Valid id";

                if (dateNow > dateEnd)
                {
                    MessageBox.Show("Ticket is expired");
                }

            }


        }
    }
}
