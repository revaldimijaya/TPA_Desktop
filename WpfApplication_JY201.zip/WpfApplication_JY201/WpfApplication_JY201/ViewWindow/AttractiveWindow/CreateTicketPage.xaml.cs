﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WpfApplication_JY201.Controller;
using WpfApplication_JY201.Factory;

namespace WpfApplication_JY201.ViewWindow.AttractiveWindow
{
    /// <summary>
    /// Interaction logic for CreateTicketPage.xaml
    /// </summary>
    public partial class CreateTicketPage : Page
    {
        public CreateTicketPage()
        {
            InitializeComponent();
        }

        private void btnCreate_Click(object sender, RoutedEventArgs e)
        {
            string ticketDate = txtTicketDate.Text;
            int ticketPrice;
            int ticketQuantity;
            bool result1 = int.TryParse(txtTicketPrice.Text, out ticketPrice);
            bool result2 = int.TryParse(txtTicketQuantity.Text, out ticketQuantity);

            if (!result1 || !result2)
            {
                MessageBox.Show("Input must be an integer!");
                return;
            }

            Ticket ticket = TicketFactory.CreateTicket(Global.GetEmployeeId(), ticketDate, ticketPrice, ticketQuantity);

            TicketController.AddTicket(ticket);
        }
    }
}
