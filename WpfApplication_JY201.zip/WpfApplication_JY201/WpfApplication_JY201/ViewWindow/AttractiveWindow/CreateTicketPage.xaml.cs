﻿using Gma.QrCodeNet.Encoding;
using Gma.QrCodeNet.Encoding.Windows.Render;
using QRCoder;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WpfApplication_JY201.Controller;
using WpfApplication_JY201.Factory;

namespace WpfApplication_JY201.ViewWindow.AttractiveWindow
{
    /// <summary>
    /// Interaction logic for CreateTicketPage.xaml
    /// </summary>
    public partial class CreateTicketPage : Page
    {
        public CreateTicketPage()
        {
            InitializeComponent();
        }

        private void QRGenerate(string mix)
        {
            QrEncoder encoder = new QrEncoder(ErrorCorrectionLevel.M);
            QrCode qrCode;
            encoder.TryEncode(mix, out qrCode);
            WriteableBitmapRenderer wRenderer = new WriteableBitmapRenderer(new FixedModuleSize(2, QuietZoneModules.Two), Colors.Black, Colors.White);
            WriteableBitmap wBitmap = new WriteableBitmap(70, 70, 96, 96, PixelFormats.Gray8, null);
            wRenderer.Draw(wBitmap, qrCode.Matrix);
            image.Source = wBitmap;
        }

        private void btnCreate_Click(object sender, RoutedEventArgs e)
        {

            if(DateTime.Now.Hour < 8 || DateTime.Now.Hour >= 22)
            {
                MessageBox.Show("UndeTheSea is closed!");
                return;
            }
            if (dpDate.SelectedDate == null)
            {
                MessageBox.Show("Invalid Input!");
                return;
            }

            DateTime ticketDate = (DateTime)dpDate.SelectedDate;

            string mix = ticketDate.ToString()+ " "+ "150000";
            QRGenerate(mix);

            Ticket ticket = TicketFactory.CreateTicket(Global.GetEmployeeId(), ticketDate, 150000);
            TicketController.AddTicket(ticket);
            IncomeController.AddIncome(IncomeFactory.CreateIncome(Global.GetDepartmentId(), 150000, "Jual ticket"));
        }
    }
}
