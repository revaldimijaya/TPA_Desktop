﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WpfApplication_JY201.Controller;

namespace WpfApplication_JY201.ViewWindow.ConstructionWindow
{
    /// <summary>
    /// Interaction logic for AttractionPlanPage.xaml
    /// </summary>
    public partial class AttractionPlanPage : Page
    {
        public AttractionPlanPage()
        {
            InitializeComponent();
            List<AttractionPlan> att = AttractionPlanController.ViewAttractionPlan();
            var filtered = att.Select(i => new
            {
                i.AttractionPlanId,
                i.AttractionPlanName,
                i.AttractionPlanStatus,
                i.AttractionPlanDescription
            });

            dgViewAttractionPlan.ItemsSource = filtered;
        }

        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {
            int id;
            int.TryParse(txtId.Text, out id);
            string status = ((ComboBoxItem)cbStatus.SelectedItem).Content.ToString();

            if (id == 0 || status == null)
            {
                MessageBox.Show("Invalid Input!");
                return;
            }

            AttractionPlanController.SetStatus(id, status);
        }
    }
}
