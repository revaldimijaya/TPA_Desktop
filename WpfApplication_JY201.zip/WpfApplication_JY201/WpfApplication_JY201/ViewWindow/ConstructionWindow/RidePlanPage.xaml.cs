﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WpfApplication_JY201.Controller;

namespace WpfApplication_JY201.ViewWindow.ConstructionWindow
{
    /// <summary>
    /// Interaction logic for RidePlanPage.xaml
    /// </summary>
    public partial class RidePlanPage : Page
    {
        public RidePlanPage()
        {
            InitializeComponent();
            List<RidePlanning> ride = RidePlanController.ViewRidePlan();
            var filtered = ride.Select(i => new
            {
                i.RidePlanningId,
                i.RideName,
                i.RideStatus,
                i.RideDescription
            });

            dgViewRidePlan.ItemsSource = filtered;

        }

        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {
            int id;
            int.TryParse(txtId.Text, out id);
            string status = ((ComboBoxItem)cbStatus.SelectedItem).Content.ToString();

            if(id == 0 || status == null)
            {
                MessageBox.Show("Invalid Input!");
                return;
            }

            RidePlanController.SetStatus(id, status);
        }
    }
}
