﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WpfApplication_JY201.Controller;
using WpfApplication_JY201.Factory;

namespace WpfApplication_JY201.ViewWindow.CreativeWindow
{
    /// <summary>
    /// Interaction logic for AttractionPlanPage.xaml
    /// </summary>
    public partial class AttractionPlanPage : Page
    {
        public AttractionPlanPage()
        {
            InitializeComponent();
            List<AttractionPlan> att = AttractionPlanController.ViewAttractionPlan();
            var filtered = att.Select(i => new
            {
                i.AttractionPlanId,
                Employee = i.Employee.EmployeeName,
                i.AttractionPlanName,
                i.AttractionPlanStatus,
                i.AttractionPlanDescription
            });

            dgViewAttractionPlan.ItemsSource = filtered;
        }

        private void btnInsert_Click(object sender, RoutedEventArgs e)
        {
            string name = txtAttractionPlanName.Text;
            string description = txtAttractionDescription.Text;

            if(name == null || description == null)
            {
                MessageBox.Show("Invalid input");
                return;
            }

            AttractionPlanController.AddAttractionPlan(AttractionPlanFactory.CreateAttractionPlan(Global.GetEmployeeId(), name, "Waiting response", description));
        }

        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {
            int id;
            int.TryParse(txtId.Text, out id);
            string name = txtAttractionPlanName.Text;
            string description = txtAttractionDescription.Text;
            if (id == 0 || name == null || description == null)
            {
                MessageBox.Show("Invalid input");
                return;
            }

            AttractionPlanController.UpdateAttractionPlan(id, name, description);
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            int id;
            int.TryParse(txtId.Text, out id);
            if (id == 0)
            {
                MessageBox.Show("Invalid input");
                return;
            }

            AttractionPlanController.RemoveAttractionPlan(id);
        }
    }
}
