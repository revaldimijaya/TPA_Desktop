﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WpfApplication_JY201.Controller;
using WpfApplication_JY201.Factory;

namespace WpfApplication_JY201.ViewWindow.CreativeWindow
{
    /// <summary>
    /// Interaction logic for AttractivePage.xaml
    /// </summary>
    public partial class AttractivePage : Page
    {
        public AttractivePage()
        {
            InitializeComponent();
            List<Attraction> att = AttractionController.ViewAttraction();
            var filtered = att.Select(i => new
            {
                i.AttractionId,
                Employee = i.Employee.EmployeeName,
                i.AttractionName,
                i.AttractionStatus,
                i.AttractionDescription
            });

            dgViewAttraction.ItemsSource = filtered;
        }


        private void btnInsert_Click(object sender, RoutedEventArgs e)
        {
            string name = txtAttractionName.Text;
            string status = ((ComboBoxItem)cbStatus.SelectedItem).Content.ToString();
            string description = txtDescription.Text;
            if (status == null || description == null || name == null)
            {
                MessageBox.Show("Invalid input");
                return;
            }

            AttractionController.AddAttraction(AttractionFactory.CreateAttraction(Global.GetEmployeeId(), name, description, status));
        }

        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {
            int id;
            int.TryParse(txtId.Text, out id);
            string status = ((ComboBoxItem)cbStatus.SelectedItem).Content.ToString();
            string description = txtDescription.Text;
            if (status == null || description == null)
            {
                MessageBox.Show("Invalid input");
                return;
            }

            AttractionController.UpdateAttraction(id, status, description);
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
