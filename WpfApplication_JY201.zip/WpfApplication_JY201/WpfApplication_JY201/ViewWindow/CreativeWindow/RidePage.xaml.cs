﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WpfApplication_JY201.Controller;
using WpfApplication_JY201.Factory;

namespace WpfApplication_JY201.ViewWindow.CreativeWindow
{
    /// <summary>
    /// Interaction logic for RidePage.xaml
    /// </summary>
    public partial class RidePage : Page
    {
        public RidePage()
        {
            InitializeComponent();
            List<Ride> ride = RideController.ViewRide();

            var filtered = ride.Select(i => new
            {
                i.RideId,
                Employee = i.Employee.EmployeeName,
                i.RideName,
                i.RideStatus,
                i.RideDescription
            });
            
            dgViewRide.ItemsSource = filtered;
        }

        private void btnInsert_Click(object sender, RoutedEventArgs e)
        {
            string name = txtRideName.Text;
            string status = ((ComboBoxItem)cbStatus.SelectedItem).Content.ToString();
            string description = txtDescription.Text;
            if (status == null || description == null || name == null)
            {
                MessageBox.Show("Invalid input");
                return;
            }

            RideController.AddRide(RideFactory.CreateRide(Global.GetEmployeeId(), name, description));
        }

        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {
            int id;
            int.TryParse(txtId.Text, out id);
            string status = ((ComboBoxItem)cbStatus.SelectedItem).Content.ToString();
            string description = txtDescription.Text;
            if (status == null || description == null)
            {
                MessageBox.Show("Invalid input");
                return;
            }

            RideController.UpdateRide(id, status, description);
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            int id;
            int.TryParse(txtId.Text, out id);
            if (id == 0)
            {
                MessageBox.Show("Invalid input");
                return;
            }
            RideController.RemoveRide(id);
        }
    }
}
