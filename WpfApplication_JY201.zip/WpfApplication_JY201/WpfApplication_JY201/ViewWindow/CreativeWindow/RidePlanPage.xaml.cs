﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WpfApplication_JY201.Controller;
using WpfApplication_JY201.Factory;

namespace WpfApplication_JY201.ViewWindow.CreativeWindow
{
    /// <summary>
    /// Interaction logic for RidePlanPage.xaml
    /// </summary>
    public partial class RidePlanPage : Page
    {
        public RidePlanPage()
        {
            InitializeComponent();
            List<RidePlanning> ride = RidePlanController.ViewRidePlan();
            var filtered = ride.Select(i => new
            {
                i.RidePlanningId,
                Employee = i.Employee.EmployeeName,
                i.RideName,
                i.RideStatus,
                i.RideDescription
            });

            dgViewRidePlan.ItemsSource = filtered;
        }

        private void btnInsert_Click(object sender, RoutedEventArgs e)
        {
            string name = txtRidePlanName.Text;
            string description = txtRideDescription.Text;

            if(name == null || description == null)
            {
                MessageBox.Show("Invalid input");
                return;
            }

            RidePlanController.AddRidePlan(RidePlanFactory.CreateRidePlan(Global.GetEmployeeId(), name, description, "Waiting Response"));
        }

        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {
            int id;
            int.TryParse(txtId.Text, out id);
            string name = txtRidePlanName.Text;
            string description = txtRideDescription.Text;

            if (id == 0 || name == null || description == null)
            {
                MessageBox.Show("Invalid input");
                return;
            }

            RidePlanController.UpdateRidePlan(id, name, description);
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            int id = -1;
            int.TryParse(txtId.Text, out id);

            if(id == -1)
            {
                MessageBox.Show("Invalid input");
                return;
            }

            RidePlanController.RemoveRidePlan(id);
        }
    }
}
