﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WpfApplication_JY201.Controller;
using WpfApplication_JY201.Factory;
using WpfApplication_JY201.Repository;

namespace WpfApplication_JY201.ViewWindow.HRDWindow
{
    /// <summary>
    /// Interaction logic for EmployeePage.xaml
    /// </summary>
    public partial class EmployeePage : Page
    {
        public EmployeePage()
        {
            InitializeComponent();
            List<Department> name = DepartmentController.ViewDepartment();
            var depart = name.Select(i => i.DepartmentName);
            cbDepartment.ItemsSource = depart;

            List<Role> roles = RoleRepository.ViewRole();
            var rl = roles.Select(i => i.RoleName);
            cbRole.ItemsSource = rl;

            List<Employee> em = EmployeController.ViewEmployee();
            var filtered = em.Select(i => new
            {
                i.EmployeeId,
                Department = i.Department.DepartmentName,
                Role = i.Role.RoleId,
                i.EmployeeEmail,
                i.EmployeeName,
                i.EmployeeAge,
                i.EmployeeSalary,
                i.EmployeeStartWork,
                i.EmployeeStatus
            });

            dgView.ItemsSource = filtered;
        }

        private void btnInsert_Click(object sender, RoutedEventArgs e)
        {
            string role = cbRole.SelectedItem.ToString();
            string department = cbDepartment.SelectedItem.ToString();
            string name = txtName.Text;
            int age;
            int.TryParse(txtAge.Text, out age);
            string email = txtEmail.Text;
            int salary;
            int.TryParse(txtSalary.Text, out salary);
            DateTime StartWork = (DateTime)dpStart.SelectedDate;
            Role _role = RoleRepository.GetOne(role);
            Department _department = DepartmentController.GetOne(department);
            if(_role == null || _department == null || name == null || age == 0 || email == null || salary == 0 || StartWork == null)
            {
                MessageBox.Show("Invalid Input");
                return;
            }

            EmployeController.AddEmployee(EmployeeFactory.CreateEmployee(_role.RoleId, _department.DepartmentId, name, age, email, "123", salary, StartWork, null, "Active"));
        }

        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {
            int id;
            int.TryParse(txtId.Text, out id);
            int salary;
            int.TryParse(txtSalary.Text, out salary);
            Employee emp = EmployeController.GetEmployee(id);
            if ( salary <= 0 || emp == null)
            {
                MessageBox.Show("Invalid Input");
                return;
            }
            EmployeController.SetEmployeeSalary(id, salary);
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            int id;
            int.TryParse(txtId.Text, out id);
            Employee emp = EmployeController.GetEmployee(id);
            if (emp == null)
            {
                MessageBox.Show("Invalid Input");
                return;
            }

            EmployeController.RemoveEmployee(id);
        }
    }
}
