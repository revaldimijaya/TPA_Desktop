﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WpfApplication_JY201.Controller;
using WpfApplication_JY201.Factory;
using WpfApplication_JY201.Repository;

namespace WpfApplication_JY201.ViewWindow.HRDWindow
{
    /// <summary>
    /// Interaction logic for PerformancePage.xaml
    /// </summary>
    public partial class PerformancePage : Page
    {
        public PerformancePage()
        {
            InitializeComponent();
            List<Employee> emp = EmployeController.ViewEmployee();
            var filter_emp = emp.Select(i => i.EmployeeName);
            cbEmployee.ItemsSource = filter_emp;

            List<Performance> per = PerformanceRepository.ViewPerformance();
            var filtered = per.Select(i => new
            {
                i.PerformanceId,
                Employee = i.Employee.EmployeeName,
                i.Date,
                i.Description
            });

            dgView.ItemsSource = filtered;
        }

        private void btnInsert_Click(object sender, RoutedEventArgs e)
        {
            string employee = cbEmployee.SelectedItem.ToString();
            DateTime date = (DateTime)dpDate.SelectedDate;
            string description = txtDescription.Text;
            Employee emp = EmployeController.GetEmployee(employee);
            if(emp == null || date == null)
            {
                MessageBox.Show("Invalid Input");
                return;
            }

            PerformanceRepository.AddPerformance(PerformanceFactory.CreatePerformance(emp.EmployeeId, date, description));
        }

        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {
            int id;
            int.TryParse(txtId.Text, out id);
            DateTime date = (DateTime)dpDate.SelectedDate;
            string description = txtDescription.Text;
            Performance per = PerformanceRepository.GetOne(id);
            if (per == null || date == null || description == null)
            {
                MessageBox.Show("Invalid Input");
                return;
            }

            PerformanceRepository.UpdatePerformance(id, date, description);
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            int id;
            int.TryParse(txtId.Text, out id);
            Performance per = PerformanceRepository.GetOne(id);
            if (per == null )
            {
                MessageBox.Show("Invalid Input");
                return;
            }

            PerformanceRepository.DeletePerformance(id);
        }
    }
}
