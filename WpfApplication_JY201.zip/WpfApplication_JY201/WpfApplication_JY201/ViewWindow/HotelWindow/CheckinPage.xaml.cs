﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WpfApplication_JY201.Controller;
using WpfApplication_JY201.Factory;

namespace WpfApplication_JY201.ViewWindow.HotelWindow
{
    /// <summary>
    /// Interaction logic for CheckinPage.xaml
    /// </summary>
    public partial class CheckinPage : Page
    {
        public CheckinPage()
        {
            InitializeComponent();
            List<Room> room = RoomController.ViewAvailableRoom();
            var filtered = room.Select(a => new
            {
                a.RoomId,
                a.RoomNumber,
                a.RoomStatus
            });

            dgView.ItemsSource = filtered;
        }

        private void btnCheckin_Click(object sender, RoutedEventArgs e)
        {
            DateTime date = (DateTime)dpDate.SelectedDate;
            string room = txtRoom.Text;
            string identity = txtIdentity.Text;
            Visitor visitor = VisitorController.GetOne(identity);
            Room rooms = RoomController.GetOne(room);
            if(date == null || room == null || identity == null || visitor == null)
            {
                MessageBox.Show("Invalid Input");
                return;
            }

            HotelTransactionController.AddHotel(HotelTransactionFactory.CreateHotel(Global.GetEmployeeId(), visitor.VisitorId, rooms.RoomId, date, "Booked", "-"));
            RoomController.SetStatus(rooms.RoomId, "Booked");
            IncomeController.AddIncome(IncomeFactory.CreateIncome(Global.GetDepartmentId(), 100000, "hotel"));
        }
    }
}
