﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WpfApplication_JY201.Controller;
using WpfApplication_JY201.Factory;
using WpfApplication_JY201.Repository;

namespace WpfApplication_JY201.ViewWindow.HotelWindow
{
    /// <summary>
    /// Interaction logic for CheckoutPage.xaml
    /// </summary>
    public partial class CheckoutPage : Page
    {
        public CheckoutPage()
        {
            InitializeComponent();
            List<HotelTransaction> ht = HotelTransactionController.ViewHotel();
            var filtered = ht.Select(i => new
            {
                i.HotelTransactionId,
                Employee = i.Employee.EmployeeName,
                Room = i.Room.RoomNumber,
                Visitor = i.Visitor.IdentityCard,
                i.BookingDate,
                i.TransactionStatus,
                i.TransactionDescription,
            });
            dgView.ItemsSource = filtered;
        }

        private void btnCheckOut_Click(object sender, RoutedEventArgs e)
        {
            DateTime date = Convert.ToDateTime(dpDate.Text);
            string identity = txtIdentity.Text;
            Visitor visitor = VisitorController.GetOne(identity);
            if (visitor == null || date == null || identity == null)
            {
                MessageBox.Show("Invalid Input");
                return;
            }

            HotelTransaction hotel = HotelTransactionController.GetVisitorId(visitor.VisitorId);
            HotelTransactionController.SetStatus(hotel.HotelTransactionId, "Already Checkout");
            RoomController.SetStatus((int)hotel.RoomId, "Need Clean");
            CleaningScheduleRepository.AddCleaning(CleaningScheduleFactory.CreateCleaning(date, null, (int)hotel.RoomId));
        }
    }
}
