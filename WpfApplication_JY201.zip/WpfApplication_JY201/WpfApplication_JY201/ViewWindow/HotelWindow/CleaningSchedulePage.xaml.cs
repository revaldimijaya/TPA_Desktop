﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WpfApplication_JY201.Controller;
using WpfApplication_JY201.Repository;

namespace WpfApplication_JY201.ViewWindow.HotelWindow
{
    /// <summary>
    /// Interaction logic for CleaningSchedulePage.xaml
    /// </summary>
    public partial class CleaningSchedulePage : Page
    {
        public CleaningSchedulePage()
        {
            InitializeComponent();
            List<CleaningSchedule> cs = CleaningScheduleRepository.ViewCleaning();
            var filtered = cs.Select(i => new
            {
                i.CleaningId,
                Room = i.Room.RoomNumber,
                i.CleaningSchedule1,
                i.CleaningStatus,

            });

            dgView.ItemsSource = filtered;
        }

        private void btnStatus_Click(object sender, RoutedEventArgs e)
        {
            int id;
            int.TryParse(txtId.Text, out id);
            string status = ((ComboBoxItem)cbStatus.SelectedItem).Content.ToString();
            string description = txtDescription.Text;

            CleaningSchedule cs = CleaningScheduleRepository.GetOne(id);
            if(cs == null || status == null)
            {
                MessageBox.Show("Invalid Input!");
                return;
            }

            CleaningScheduleRepository.SetStatus(id, status, description);
            RoomController.SetStatus((int)cs.RoomId, status);
        }
    }
}
