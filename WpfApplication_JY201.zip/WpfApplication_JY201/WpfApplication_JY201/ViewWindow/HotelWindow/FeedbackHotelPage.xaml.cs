﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WpfApplication_JY201.Factory;
using WpfApplication_JY201.Repository;

namespace WpfApplication_JY201.ViewWindow.HotelWindow
{
    /// <summary>
    /// Interaction logic for FeedbackHotelPage.xaml
    /// </summary>
    public partial class FeedbackHotelPage : Page
    {
        public FeedbackHotelPage()
        {
            InitializeComponent();
            List<FeedbackHotel> fd = FeedbackHotelRepository.ViewFeedback();
            var fi = fd.Select(i => new
            {
                i.FeedbackId,
                i.Description
            });

            dgView.ItemsSource = fi;
        }

        private void btnSubmit_Click(object sender, RoutedEventArgs e)
        {
            string desc = txtRating.Text;
            FeedbackHotelRepository.AddFeedback(FeebackHotelFactory.CreateFeedback(1, desc));
        }
    }
}
