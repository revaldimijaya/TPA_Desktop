﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApplication_JY201.ViewWindow.HotelWindow
{
    /// <summary>
    /// Interaction logic for HouseKeeperWindow.xaml
    /// </summary>
    public partial class HouseKeeperWindow : Window
    {
        public HouseKeeperWindow()
        {
            InitializeComponent();
        }

        private void btnCleaning_Click(object sender, RoutedEventArgs e)
        {
            Main.Content = new CleaningSchedulePage();
        }

        private void btnLogOut_Click(object sender, RoutedEventArgs e)
        {
            LoginWindow objLw = new LoginWindow();
            objLw.Show();
            this.Close();
        }

        private void btnRequest_Click(object sender, RoutedEventArgs e)
        {
            Main.Content = new RequestPage.RequestPage();
        }
    }
}
