﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WpfApplication_JY201.Controller;
using WpfApplication_JY201.Factory;

namespace WpfApplication_JY201.ViewWindow.HotelWindow
{
    /// <summary>
    /// Interaction logic for MembersPage.xaml
    /// </summary>
    public partial class MembersPage : Page
    {
        public MembersPage()
        {
            InitializeComponent();
            List<Visitor> visitor = VisitorController.ViewVisitor();
            var filtered = visitor.Select(a => new
            {
                a.VisitorId,
                a.VisitorName,
                a.IdentityCard
            });

            dgView.ItemsSource = filtered;
            
        }

        private void btnInsert_Click(object sender, RoutedEventArgs e)
        {
            string name = txtName.Text;
            string identity = txtIdentity.Text;
            if(name == null || identity == null)
            {
                MessageBox.Show("Invalid Input!");
                return;
            }

            VisitorController.AddVisitor(VisitorFactory.CreateVisitor(name, identity));
        }

        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {
            int id;
            int.TryParse(txtId.Text, out id);
            string name = txtName.Text;
            string identity = txtIdentity.Text;
            Visitor visitor = VisitorController.GetOne(id);
            if (visitor == null || name == null || identity == null)
            {
                MessageBox.Show("Invalid Input!");
                return;
            }

            VisitorController.UpdateVisitor(id, name, identity);
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            int id;
            int.TryParse(txtId.Text, out id);
            Visitor visitor = VisitorController.GetOne(id);
            if (visitor == null )
            {
                MessageBox.Show("Invalid Input!");
                return;
            }
            VisitorController.DeleteVisitor(id);
        }
    }
}
