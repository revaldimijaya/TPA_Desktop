﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WpfApplication_JY201.Controller;
using WpfApplication_JY201.Factory;

namespace WpfApplication_JY201.ViewWindow.MaintenanceWindow
{
    /// <summary>
    /// Interaction logic for ViewAttractionPage.xaml
    /// </summary>
    public partial class ViewAttractionPage : Page
    {
        public ViewAttractionPage()
        {
            InitializeComponent();
            List<Attraction> att = AttractionController.ViewAttraction();
            var filtered = att.Select(i => new
            {
                i.AttractionId,
                i.EmployeeId,
                i.AttractionName,
                i.AttractionDescription,
                i.AttractionStatus
            });

            dgViewAttraction.ItemsSource = filtered;
        }

        private void btnSubmit_Click(object sender, RoutedEventArgs e)
        {
            int id;
            string status = ((ComboBoxItem)cbStatus.SelectedItem).Content.ToString();
            string description = txtDescription.Text.ToString();
            DateTime sDate = (DateTime)dpStart.SelectedDate;
            DateTime fDate = (DateTime)dpEnd.SelectedDate;
            int.TryParse(txtId.Text, out id);

            if (id == 0 || status == null || description == null || dpStart.SelectedDate == null || dpEnd.SelectedDate == null || fDate < sDate)
            {
                MessageBox.Show("Input must be an integer / input is empty!");
                return;
            }

            AttractionController.UpdateAttraction(id, status, description);
            if (status == "Under Maintenance")
                AttractionMaintenanceController.AddAttractionMaintenance(AttractionMaintenanceFactory.CreateAttractionMaintenance(id, sDate, fDate));
        }
    }
}
