﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WpfApplication_JY201.Controller;

namespace WpfApplication_JY201.ViewWindow.MaintenanceWindow
{
    /// <summary>
    /// Interaction logic for ViewRideMaintenance.xaml
    /// </summary>
    public partial class ViewRideMaintenance : Page
    {
        public ViewRideMaintenance()
        {
            InitializeComponent();
            List<RideMaintenance> rm = RideMaintenanceController.ViewRideMaintenance();
            var filtered = rm.Select(i => new
            {
                i.RideMaintenanceId,
                Ride = i.Ride.RideName,
                i.StartDateMaintenance,
                i.FinishDateMaintenance
            });

            dgViewRuideMaintenance.ItemsSource = filtered;
        }

        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {
            int id;
            int.TryParse(txtId.Text, out id);
            DateTime sDate = (DateTime)dpStart.SelectedDate;
            DateTime fDate = (DateTime)dpEnd.SelectedDate;
            int.TryParse(txtId.Text, out id);

            if (id == 0 || dpStart.SelectedDate == null || dpEnd.SelectedDate == null || fDate < sDate)
            {
                MessageBox.Show("Input must be an integer / input is empty!");
                return;
            }

            RideMaintenanceController.UpdateRideMaintenance(id, sDate, fDate);
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            int id;
            int.TryParse(txtId.Text, out id);

            if(id == 0)
            {
                MessageBox.Show("is empty");
                return;
            }

            RideMaintenanceController.RemoveRideMaintenance(id);
        }
    }
}
