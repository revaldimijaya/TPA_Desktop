﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using WpfApplication_JY201.ViewWindow.HRDWindow;
using WpfApplication_JY201.ViewWindow.RequestPage;

namespace WpfApplication_JY201.ViewWindow.ManagerWindow
{
    /// <summary>
    /// Interaction logic for ManagerWindow.xaml
    /// </summary>
    public partial class ManagerWindow : Window
    {
        public ManagerWindow()
        {
            InitializeComponent();
        }

        private void btnRequest_Click(object sender, RoutedEventArgs e)
        {
            Main.Content = new RequestPage.IncomingPage();
        }

        private void btnIncome_Click(object sender, RoutedEventArgs e)
        {
            Main.Content = new ViewIncomePage();
        }

        private void btnLogOut_Click(object sender, RoutedEventArgs e)
        {
            LoginWindow objLw = new LoginWindow();
            objLw.Show();
            this.Close();
        }

        private void btnPerformance_Click(object sender, RoutedEventArgs e)
        {
            Main.Content = new PerformancePage();
        }
    }
}
