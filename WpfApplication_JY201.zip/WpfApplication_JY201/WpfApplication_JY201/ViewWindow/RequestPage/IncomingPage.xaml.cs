﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WpfApplication_JY201.Controller;

namespace WpfApplication_JY201.ViewWindow.RequestPage
{
    /// <summary>
    /// Interaction logic for IncomingPage.xaml
    /// </summary>
    public partial class IncomingPage : Page
    {
        public IncomingPage()
        {
            InitializeComponent();
            List<Request> req = RequestController.IncomingRequest(Global.GetDepartmentId());
            var request = req.Select(i => new
            {
                i.RequestId,
                RequestType = i.RequestType.RequestTypeName,
                FromDepartment = i.Department1.DepartmentName,
                ToDepartment = i.Department.DepartmentName,
                i.RequestDescription,
                i.RequestStatus
            });

            dgView.ItemsSource = request;
        }

        private void btnSetStatus_Click(object sender, RoutedEventArgs e)
        {
            int id;
            int.TryParse(txtId.Text, out id);
            string status = ((ComboBoxItem)cbStatus.SelectedItem).Content.ToString();
            if (id == 0 || status == null)
            {
                MessageBox.Show("Invalid input");
                return;
            }
            RequestController.SetStatus(id, status);
        }
    }
}
