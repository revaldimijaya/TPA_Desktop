﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WpfApplication_JY201.Controller;
using WpfApplication_JY201.Factory;

namespace WpfApplication_JY201.ViewWindow.RequestPage
{
    /// <summary>
    /// Interaction logic for RequestPage.xaml
    /// </summary>
    public partial class RequestPage : Page
    {
        public RequestPage()
        {
            InitializeComponent();
            if(Global.GetEmployeeId() != 15)
            {
                lblStatus.Visibility = Visibility.Hidden;
                cbStatus.Visibility = Visibility.Hidden;
                btnSetStatus.Visibility = Visibility.Hidden;
            }

            int id = Global.GetDepartmentId();
            cbType.Items.Add("Leave Permit");
            cbType.Items.Add("Resign");
            cbDepartment.Items.Add("Human Resource Department");
            cbDepartment.Items.Add("Manager");
            if (id == 3 || id == 4 || id == 9)
            {
                cbType.Items.Add("Purchase Request");
                cbType.Items.Add("Fund Request");
                cbDepartment.Items.Add("Purchasing Department");
                cbDepartment.Items.Add("Accounting and Finance Department");
            }

            if(id == 5)
            {
                if(Global.GetEmployeeId() == 5)
                {
                    return;
                }
                cbType.Items.Add("Purchase Request");
                cbDepartment.Items.Add("Purchasing Department");
            }

            if(id == 6)
            {
                cbType.Items.Add("Fund Request");
                cbDepartment.Items.Add("Accounting and Finance Department");
            }

            if(id == 10)
            {
                cbType.Items.Remove("Human Resource Department");
                cbType.Items.Add("Fund Request");
                cbType.Items.Add("Firing & Evidance");
                cbDepartment.Items.Add("Accounting and Finance Department");
            }
         

            List<Request> req = RequestController.MakeRequest(Global.GetEmployeeId());
            var request = req.Select(i => new
            {
                i.RequestId,
                RequestType = i.RequestType.RequestTypeName,
                FromDepartment = i.Department1.DepartmentName,
                ToDepartment = i.Department.DepartmentName,
                Employee = i.Employee.EmployeeName,
                i.CreatedAt,
                i.RequestDescription,
                i.RequestStatus
            });

            dgView.ItemsSource = request;
        }

        private void btnInsert_Click(object sender, RoutedEventArgs e)
        {
            string type = cbType.SelectedItem.ToString();
            string toDepartment = cbDepartment.SelectedItem.ToString();
            string description = txtDescription.Text;

            if(type == null || toDepartment == null || description == null)
            {
                MessageBox.Show("Invalid input");
                return;
            }

            int idType = RequestTypeController.GetOne(type).RequestTypeId;
            int idToDepartment = DepartmentController.GetOne(toDepartment).DepartmentId;

            RequestController.AddRequest(RequestFactory.CreateRequest(idType, idToDepartment, description));
        }

        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {
            int id;
            int.TryParse(txtId.Text, out id);
            string type = cbType.SelectedItem.ToString();
            string toDepartment = cbDepartment.SelectedItem.ToString();
            string description = txtDescription.Text;
            if (id == 0 || type == null || toDepartment == null || description == null)
            {
                MessageBox.Show("Invalid input");
                return;
            }

            int idType = RequestTypeController.GetOne(type).RequestTypeId;
            int idToDepartment = DepartmentController.GetOne(toDepartment).DepartmentId;

            RequestController.UpdateRequest(id, idType, idToDepartment, description);
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            int id;
            int.TryParse(txtId.Text, out id);
            if (id == 0 )
            {
                MessageBox.Show("Invalid input");
                return;
            }

            RequestController.DeleteRequest(id);
        }

        private void btnSetStatus_Click(object sender, RoutedEventArgs e)
        {
            int id;
            int.TryParse(txtId.Text, out id);
            string status = ((ComboBoxItem)cbStatus.SelectedItem).Content.ToString();
            if (id == 0 || status == null)
            {
                MessageBox.Show("Invalid input");
                return;
            }
            RequestController.SetStatus(id, status);
        }
    }
}

