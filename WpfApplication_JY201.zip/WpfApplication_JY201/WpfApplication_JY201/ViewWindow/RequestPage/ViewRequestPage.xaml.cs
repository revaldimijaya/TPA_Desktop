﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WpfApplication_JY201.Controller;

namespace WpfApplication_JY201.ViewWindow.RequestPage
{
    /// <summary>
    /// Interaction logic for ViewRequestPage.xaml
    /// </summary>
    public partial class ViewRequestPage : Page
    {
        public ViewRequestPage()
        {
            InitializeComponent();
            List<Request> request = RequestController.ViewRequest();

            var filtered = request.Select(i => new
            {
                i.RequestId,
                i.FromDepartmentId,
                i.ToDepartmentId,
                RequestType = i.RequestType.RequestTypeName,
                i.RequestDescription,
                i.RequestStatus
            });

            dgViewRequest.ItemsSource = filtered;
        }

        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {
            string status = ((ListBoxItem)txtStatus.SelectedItem).Content.ToString();
            int id;
            int.TryParse(txtId.Text, out id);

            if (id == 0)
            {
                MessageBox.Show("input must be an integer!");
                return;
            }

            RequestController.SetStatus(id, status);

        }
    }
}
