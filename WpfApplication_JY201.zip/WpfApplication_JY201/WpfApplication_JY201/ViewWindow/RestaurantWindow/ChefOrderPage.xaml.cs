﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WpfApplication_JY201.Controller;

namespace WpfApplication_JY201.ViewWindow.RestaurantWindow
{
    /// <summary>
    /// Interaction logic for ChefOrderPage.xaml
    /// </summary>
    public partial class ChefOrderPage : Page
    {
        public ChefOrderPage()
        {
            InitializeComponent();
            List<Order> order = OrderController.ViewOrderChef();
            var filtered = order.Select(i => new
            {
                i.OrderId,
                i.OrderTable,
                i.OrderDescription,
                i.OrderStatus,
            });

            dgView.ItemsSource = filtered;
        }

        private void btnDeliver_Click(object sender, RoutedEventArgs e)
        {
            int id;
            int.TryParse(txtId.Text, out id);
            Order order = OrderController.GetOne(id);
            if(id <= 0 || order == null)
            {
                MessageBox.Show("Id not found");
                return;
            }

            OrderController.SetStatus(id, "Delivered");
        }
    }
}
