﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WpfApplication_JY201.Controller;
using WpfApplication_JY201.Factory;
using WpfApplication_JY201.Repository;

namespace WpfApplication_JY201.ViewWindow.RestaurantWindow
{
    /// <summary>
    /// Interaction logic for OrderPage.xaml
    /// </summary>
    public partial class OrderPage : Page
    {
        public OrderPage()
        {
            InitializeComponent();
            List<Order> order = OrderController.ViewOrder();
            var filtered = order.Select(i => new
            {
                i.OrderId,
                i.OrderTable,
                i.OrderDescription,
                i.OrderAmount,
                i.OrderStatus,
            });

            dgView.ItemsSource = filtered;
            
        }

        private void btnInsert_Click(object sender, RoutedEventArgs e)
        {
            int table, amount;
            int.TryParse(txtTable.Text, out table);
            int.TryParse(txtAmount.Text, out amount);
            string status = ((ComboBoxItem)cbStatus.SelectedItem).Content.ToString();
            string description = txtDescription.Text;
            if (table <= 0 || status == null || description == null || amount <= 0)
            {
                MessageBox.Show("Invalid input");
                return;
            }

            OrderController.AddOrder(OrderFactory.CreateOrder(table, description, amount, status));
        }

        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {
            int id, table, amount;
            int.TryParse(txtTable.Text, out table);
            int.TryParse(txtAmount.Text, out amount);
            int.TryParse(txtId.Text, out id);
            string status = ((ComboBoxItem)cbStatus.SelectedItem).Content.ToString();
            string description = txtDescription.Text;
            if (table <= 0 || status == null || description == null || amount <= 0)
            {
                MessageBox.Show("Invalid input");
                return;
            }
            OrderController.UpdateOrder(id, table, description, amount);
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            int id;
            int.TryParse(txtId.Text, out id);
            Order order = OrderController.GetOne(id);
            if(id <= 0 || order == null)
            {
                MessageBox.Show("Invalid input");
                return;
            }
            OrderController.DeleteOrder(id);
        }

        private void btnSetStatus_Click(object sender, RoutedEventArgs e)
        {
            int id;
            int.TryParse(txtId.Text, out id);
            string status = ((ComboBoxItem)cbStatus.SelectedItem).Content.ToString();
            Order order = OrderController.GetOne(id);
            if (id <= 0 || order == null || status == null)
            {
                MessageBox.Show("Invalid input");
                return;
            }
            OrderController.SetStatus(id, status);
        }
    }
}
