﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WpfApplication_JY201.Factory;
using WpfApplication_JY201.Repository;

namespace WpfApplication_JY201.ViewWindow.RestaurantWindow
{
    /// <summary>
    /// Interaction logic for RestaurantFeedbackPage.xaml
    /// </summary>
    public partial class RestaurantFeedbackPage : Page
    {
        public RestaurantFeedbackPage()
        {
            InitializeComponent();
            List<FeedbackRestaurant> fd = FeedbackRestaurantRepository.ViewFeedback();
            var fi = fd.Select(i => new
            {
                i.FeedbackId,
                i.Description
            });

            dgView.ItemsSource = fi;
        }

        private void btnSubmit_Click(object sender, RoutedEventArgs e)
        {
            string desc = txtRating.Text;
            FeedbackRestaurantRepository.AddFeedback(FeedbackRestaurantFactory.CreateFeedback(1, desc));
        }
    }
}
