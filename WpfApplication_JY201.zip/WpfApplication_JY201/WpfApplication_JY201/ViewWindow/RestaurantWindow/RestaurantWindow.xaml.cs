﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApplication_JY201.ViewWindow.RestaurantWindow
{
    /// <summary>
    /// Interaction logic for RestaurantWindow.xaml
    /// </summary>
    public partial class RestaurantWindow : Window
    {
        public RestaurantWindow()
        {
            InitializeComponent();
        }

        private void btnOrder_Click(object sender, RoutedEventArgs e)
        {
            Main.Content = new OrderPage();
        }

        private void btnLogOut_Click(object sender, RoutedEventArgs e)
        {
            LoginWindow objLw = new LoginWindow();
            objLw.Show();
            this.Close();
        }

        private void btnTotalAmount_Click(object sender, RoutedEventArgs e)
        {
            Main.Content = new TotalPage();
        }

        private void btnRequest_Click(object sender, RoutedEventArgs e)
        {
            Main.Content = new RequestPage.RequestPage();
        }

        private void btnFeedback_Click(object sender, RoutedEventArgs e)
        {
            Main.Content = new RestaurantFeedbackPage();
        }
    }
}
