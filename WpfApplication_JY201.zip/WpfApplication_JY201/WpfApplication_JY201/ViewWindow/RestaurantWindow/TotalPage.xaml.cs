﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WpfApplication_JY201.Controller;
using WpfApplication_JY201.Factory;

namespace WpfApplication_JY201.ViewWindow.RestaurantWindow
{
    /// <summary>
    /// Interaction logic for TotalPage.xaml
    /// </summary>
    public partial class TotalPage : Page
    {
        public TotalPage()
        {
            InitializeComponent();
        }

        private void btnSearch_Click(object sender, RoutedEventArgs e)
        {
            int id;
            int.TryParse(txtId.Text, out id);
            Order order = OrderController.GetOne(id);
            if(id <= 0 || order == null)
            {
                MessageBox.Show("Id not found");
                return;
            }
            if(order.OrderStatus == "Paid")
            {
                MessageBox.Show("Order already paid!");
                return;
            }

            Tax tax = new Tax((int)order.OrderAmount);

            lblId.Content = "Order : " + id;
            lblAmount.Content = "Amount : " + order.OrderAmount.ToString();
            lblTax.Content = "Tax : " + tax.CalculateTax().ToString();
            lblTotal.Content = "Total Amount : " + tax.TotalAmount().ToString();
            OrderController.SetStatus(id, "Paid");
            IncomeController.AddIncome(IncomeFactory.CreateIncome(Global.GetDepartmentId(), tax.TotalAmount(), "order makanan"));
        }
    }
}
